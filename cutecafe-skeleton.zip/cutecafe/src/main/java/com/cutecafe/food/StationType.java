package com.cutecafe.food;

import com.mojang.serialization.Codec;
import net.minecraft.util.StringRepresentable;

public enum StationType implements StringRepresentable {
    CUTTING_BOARD("cutting_board"),
    PREP_TABLE("prep_table"),
    OVEN("oven"),
    GRILL("grill"),
    RICE_COOKER("rice_cooker");

    public static final Codec<StationType> CODEC = StringRepresentable.fromEnum(StationType::values);

    private final String name;

    StationType(String name) {
        this.name = name;
    }

    @Override
    public String getSerializedName() {
        return name;
    }
}
