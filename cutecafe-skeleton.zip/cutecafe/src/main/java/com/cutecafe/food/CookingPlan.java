package com.cutecafe.food;

import com.cutecafe.CuteCafe;
import com.cutecafe.registry.ModBlocks;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.block.Block;

import javax.annotation.Nullable;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;

/**
 * The chain of steps needed to make a dish, derived from the station recipes:
 * fetch raw ingredients from crates, then work through stations until the dish is done.
 */
public final class CookingPlan {
    private static final int MAX_DEPTH = 8;

    /** Either "take an ingredient from its crate" or "run a station recipe". */
    public record Step(@Nullable ResourceLocation fetch, @Nullable StationRecipe recipe) {
        public boolean isFetch() {
            return fetch != null;
        }

        /** The crate or station block the cook has to walk to. */
        public Block block() {
            if (fetch != null) return ModBlocks.CRATES.get(fetch.getPath()).get();
            return ModBlocks.STATIONS.get(recipe.station()).get();
        }

        public ResourceLocation resultId() {
            return fetch != null ? fetch : recipe.output();
        }

        public int workTicks() {
            return fetch != null ? 10 : Math.max(40, recipe.time());
        }
    }

    private final List<Step> steps = new ArrayList<>();
    private boolean valid;

    private CookingPlan() {
    }

    public static CookingPlan invalid() {
        return new CookingPlan();
    }

    public static CookingPlan forItem(ResourceLocation target) {
        CookingPlan plan = new CookingPlan();
        plan.valid = expand(target, plan.steps, 0);
        return plan;
    }

    public boolean isValid() {
        return valid && !steps.isEmpty();
    }

    public List<Step> steps() {
        return steps;
    }

    public Set<Block> requiredBlocks() {
        Set<Block> blocks = new LinkedHashSet<>();
        for (Step s : steps) blocks.add(s.block());
        return blocks;
    }

    private static boolean isCrateIngredient(ResourceLocation item) {
        return item.getNamespace().equals(CuteCafe.MOD_ID)
                && FoodIds.INGREDIENTS.contains(item.getPath())
                && ModBlocks.CRATES.containsKey(item.getPath());
    }

    private static boolean expand(ResourceLocation item, List<Step> out, int depth) {
        if (depth > MAX_DEPTH) return false;
        if (isCrateIngredient(item)) {
            out.add(new Step(item, null));
            return true;
        }
        Optional<StationRecipe> recipe = StationRecipes.INSTANCE.byOutput(item);
        if (recipe.isEmpty()) return false;
        for (ResourceLocation input : recipe.get().inputs()) {
            if (!expand(input, out, depth + 1)) return false;
        }
        out.add(new Step(null, recipe.get()));
        return true;
    }
}
