package com.cutecafe.food;

import com.cutecafe.CuteCafe;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonElement;
import com.mojang.serialization.JsonOps;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.packs.resources.ResourceManager;
import net.minecraft.server.packs.resources.SimpleJsonResourceReloadListener;
import net.minecraft.util.profiling.ProfilerFiller;
import net.minecraft.world.item.ItemStack;

import java.util.ArrayList;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

public class StationRecipes extends SimpleJsonResourceReloadListener {
    private static final Gson GSON = new GsonBuilder().create();
    public static final StationRecipes INSTANCE = new StationRecipes();

    private Map<StationType, List<StationRecipe>> recipes = new EnumMap<>(StationType.class);

    private StationRecipes() {
        super(GSON, "station_recipes");
    }

    @Override
    protected void apply(Map<ResourceLocation, JsonElement> objects, ResourceManager manager, ProfilerFiller profiler) {
        Map<StationType, List<StationRecipe>> loaded = new EnumMap<>(StationType.class);
        objects.forEach((id, json) -> StationRecipe.CODEC.parse(JsonOps.INSTANCE, json)
                .resultOrPartial(err -> CuteCafe.LOGGER.error("Bad station recipe {}: {}", id, err))
                .ifPresent(r -> loaded.computeIfAbsent(r.station(), k -> new ArrayList<>()).add(r)));
        this.recipes = loaded;
        CuteCafe.LOGGER.info("Loaded {} station recipes", loaded.values().stream().mapToInt(List::size).sum());
    }

    /** The recipe that produces this item, if any. */
    public Optional<StationRecipe> byOutput(ResourceLocation output) {
        return recipes.values().stream().flatMap(List::stream)
                .filter(r -> r.output().equals(output)).findFirst();
    }

    /** Can this item be an input of any recipe at this station? */
    public boolean accepts(StationType type, ResourceLocation item) {
        return recipes.getOrDefault(type, List.of()).stream().anyMatch(r -> r.inputs().contains(item));
    }

    /** Recipe whose inputs exactly match what is on the station. */
    public Optional<StationRecipe> find(StationType type, List<ItemStack> contents) {
        List<String> ids = contents.stream()
                .filter(s -> !s.isEmpty())
                .map(s -> BuiltInRegistries.ITEM.getKey(s.getItem()).toString())
                .sorted().toList();
        if (ids.isEmpty()) return Optional.empty();
        return recipes.getOrDefault(type, List.of()).stream()
                .filter(r -> r.sortedInputs().equals(ids))
                .findFirst();
    }
}
