package com.cutecafe.food;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.minecraft.resources.ResourceLocation;

import java.util.List;

/**
 * data/<ns>/station_recipes/*.json
 *
 * @param inputs items that must be on the station (order doesn't matter)
 * @param time   0 = instant (made when the player clicks), otherwise cooking time in ticks
 */
public record StationRecipe(StationType station, List<ResourceLocation> inputs, ResourceLocation output, int time) {
    public static final Codec<StationRecipe> CODEC = RecordCodecBuilder.create(i -> i.group(
            StationType.CODEC.fieldOf("station").forGetter(StationRecipe::station),
            ResourceLocation.CODEC.listOf().fieldOf("inputs").forGetter(StationRecipe::inputs),
            ResourceLocation.CODEC.fieldOf("output").forGetter(StationRecipe::output),
            Codec.INT.optionalFieldOf("time", 0).forGetter(StationRecipe::time)
    ).apply(i, StationRecipe::new));

    public List<String> sortedInputs() {
        return inputs.stream().map(ResourceLocation::toString).sorted().toList();
    }
}
