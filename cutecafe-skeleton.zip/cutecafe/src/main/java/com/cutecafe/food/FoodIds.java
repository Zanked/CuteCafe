package com.cutecafe.food;

import java.util.ArrayList;
import java.util.List;

/** Names of all custom food items. Each one gets an item, model, texture and lang entry. */
public class FoodIds {
    /** Raw ingredients, available from supply crates. */
    public static final List<String> INGREDIENTS = List.of(
            "flour", "tomato", "cheese", "sausage", "frankfurter", "patty", "lettuce", "rice", "nori", "fish");

    /** Made at stations along the way. */
    public static final List<String> INTERMEDIATES = List.of(
            "dough", "tomato_slices", "cheese_slices", "sausage_slices", "lettuce_leaves", "fish_slices",
            "cooked_rice", "grilled_patty", "grilled_frankfurter", "bun", "raw_pizza");

    /** Finished dishes customers order. */
    public static final List<String> DISHES = List.of("pizza", "burger", "hot_dog", "sushi_roll");

    public static final List<String> ALL = new ArrayList<>();

    static {
        ALL.addAll(INGREDIENTS);
        ALL.addAll(INTERMEDIATES);
        ALL.addAll(DISHES);
    }
}
