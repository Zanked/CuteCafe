package com.cutecafe.entity;

import com.cutecafe.dish.Dish;
import com.cutecafe.dish.DishManager;
import com.cutecafe.entity.goal.GoToTableGoal;
import com.cutecafe.menu.CafeMenu;
import com.cutecafe.order.Order;
import com.cutecafe.order.OrderBoard;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.util.Mth;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;

import javax.annotation.Nullable;

public class CustomerEntity extends PathfinderMob {
    private static final int PATIENCE_TICKS = 20 * 60 * 5; // 5 minutes
    private static final int IDLE_TICKS = 20 * 90; // 90 s without ordering and they leave

    /** Number of customer looks (textures customer_0 ... customer_5). */
    public static final int VARIANTS = 6;
    private static final EntityDataAccessor<Integer> DATA_VARIANT =
            SynchedEntityData.defineId(CustomerEntity.class, EntityDataSerializers.INT);

    @Nullable private ResourceLocation dishId;
    @Nullable private BlockPos table;
    private int waitTicks;
    private int price;
    private int idleTicks;

    public CustomerEntity(EntityType<? extends CustomerEntity> type, Level level) {
        super(type, level);
        entityData.set(DATA_VARIANT, getRandom().nextInt(VARIANTS));
    }

    @Override
    protected void defineSynchedData(SynchedEntityData.Builder builder) {
        super.defineSynchedData(builder);
        builder.define(DATA_VARIANT, 0);
    }

    public int getVariant() {
        return Mth.clamp(entityData.get(DATA_VARIANT), 0, VARIANTS - 1);
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Mob.createMobAttributes()
                .add(Attributes.MAX_HEALTH, 20.0)
                .add(Attributes.MOVEMENT_SPEED, 0.25);
    }

    @Override
    protected void registerGoals() {
        goalSelector.addGoal(0, new FloatGoal(this));
        goalSelector.addGoal(1, new GoToTableGoal(this));
        goalSelector.addGoal(2, new LookAtPlayerGoal(this, Player.class, 6.0f));
        goalSelector.addGoal(3, new RandomLookAroundGoal(this));
    }

    public boolean hasOrder() {
        return dishId != null;
    }

    /** Called when the customer reaches a table: pick a dish and post the order. */
    public void placeOrder(BlockPos tablePos) {
        var menu = CafeMenu.available(level(), tablePos);
        if (menu.isEmpty()) return;
        CafeMenu.Entry pick = menu.get(getRandom().nextInt(menu.size()));

        this.dishId = pick.id();
        this.price = pick.price();
        this.table = tablePos;
        this.waitTicks = 0;
        OrderBoard.add(new Order(getUUID(), dishId, tablePos));
        getNavigation().stop();

        // Placeholder for a speech bubble: show the wish as a name tag
        DishManager.INSTANCE.get(dishId).ifPresent(d -> {
            Item item = BuiltInRegistries.ITEM.get(d.result());
            setCustomName(Component.translatable("cutecafe.wants", item.getDescription()));
            setCustomNameVisible(true);
        });
    }

    /** Serve the dish: right-click the customer holding the wanted item. */
    @Override
    protected InteractionResult mobInteract(Player player, InteractionHand hand) {
        if (dishId == null) return InteractionResult.PASS;
        Dish dish = DishManager.INSTANCE.get(dishId).orElse(null);
        if (dish == null) return InteractionResult.PASS;

        ItemStack held = player.getItemInHand(hand);
        if (!held.is(BuiltInRegistries.ITEM.get(dish.result()))) return InteractionResult.PASS;

        if (!level().isClientSide) {
            if (!player.getAbilities().instabuild) held.shrink(1);
            receiveDish(player);
        }
        return InteractionResult.sidedSuccess(level().isClientSide);
    }

    /** The dish arrived: pay (to the player, or dropped on the floor if a waiter served) and leave. */
    public void receiveDish(@Nullable Player payer) {
        if (level().isClientSide || dishId == null) return;
        int payment = price > 0 ? price : DishManager.INSTANCE.get(dishId).map(Dish::price).orElse(1);
        ItemStack coins = new ItemStack(Items.EMERALD, payment);
        if (payer != null) payer.addItem(coins);
        if (!coins.isEmpty()) spawnAtLocation(coins);
        level().playSound(null, blockPosition(), SoundEvents.VILLAGER_YES, SoundSource.NEUTRAL, 1.0f, 1.0f);
        discard();
    }

    @Override
    public void tick() {
        super.tick();
        if (level().isClientSide) return;
        if (dishId != null) {
            if (++waitTicks > PATIENCE_TICKS) discard(); // lost patience and left
        } else if (++idleTicks > IDLE_TICKS) {
            discard(); // never found a table
        }
    }

    @Override
    public void remove(RemovalReason reason) {
        OrderBoard.remove(getUUID());
        super.remove(reason);
    }

    @Override
    public boolean removeWhenFarAway(double distance) {
        return dishId == null;
    }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putInt("Variant", entityData.get(DATA_VARIANT));
        if (dishId != null) {
            tag.putString("Dish", dishId.toString());
            tag.putInt("WaitTicks", waitTicks);
            tag.putInt("Price", price);
        }
        if (table != null) tag.putLong("Table", table.asLong());
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        if (tag.contains("Variant")) entityData.set(DATA_VARIANT, tag.getInt("Variant"));
        if (tag.contains("Dish")) {
            dishId = ResourceLocation.tryParse(tag.getString("Dish"));
            waitTicks = tag.getInt("WaitTicks");
            price = tag.getInt("Price");
        }
        if (tag.contains("Table")) table = BlockPos.of(tag.getLong("Table"));
        if (dishId != null && table != null) {
            OrderBoard.add(new Order(getUUID(), dishId, table));
        }
    }
}
