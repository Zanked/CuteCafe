package com.cutecafe.entity;

import com.cutecafe.block.CashRegisterBlockEntity;
import com.cutecafe.entity.goal.CashierGoal;
import com.cutecafe.entity.goal.CookGoal;
import com.cutecafe.entity.goal.WaiterGoal;
import com.cutecafe.menu.CashRegisters;
import com.cutecafe.order.OrderBoard;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.Mth;
import net.minecraft.util.StringRepresentable;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

import javax.annotation.Nullable;
import java.util.Objects;

/** Hired helper. Role decides which goals it will run (cook / waiter / cashier). */
public class StaffEntity extends PathfinderMob {
    public enum Role implements StringRepresentable {
        COOK, WAITER, CASHIER;

        @Override
        public String getSerializedName() {
            return name().toLowerCase();
        }

        /** Emeralds paid every pay period. */
        public int wage() {
            return switch (this) {
                case COOK -> 4;
                case WAITER, CASHIER -> 3;
            };
        }

        public Role next() {
            return values()[(ordinal() + 1) % values().length];
        }
    }

    private static final EntityDataAccessor<Integer> DATA_ROLE =
            SynchedEntityData.defineId(StaffEntity.class, EntityDataSerializers.INT);

    /** Wages are paid out of the nearest cash register every PAY_PERIOD ticks (hired helpers only). */
    public static final int PAY_PERIOD = 20 * 60 * 3;
    private static final int MAX_MISSED_PAYS = 2;

    @Nullable private Component hint;
    private boolean hired;
    private int wageTimer;
    private int unpaidPeriods;

    public StaffEntity(EntityType<? extends StaffEntity> type, Level level) {
        super(type, level);
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Mob.createMobAttributes()
                .add(Attributes.MAX_HEALTH, 20.0)
                .add(Attributes.MOVEMENT_SPEED, 0.25);
    }

    @Override
    protected void defineSynchedData(SynchedEntityData.Builder builder) {
        super.defineSynchedData(builder);
        builder.define(DATA_ROLE, 0);
    }

    @Override
    protected void registerGoals() {
        goalSelector.addGoal(0, new FloatGoal(this));
        goalSelector.addGoal(1, new CookGoal(this));
        goalSelector.addGoal(1, new WaiterGoal(this));
        goalSelector.addGoal(1, new CashierGoal(this));
        goalSelector.addGoal(5, new WaterAvoidingRandomStrollGoal(this, 0.8));
        goalSelector.addGoal(6, new LookAtPlayerGoal(this, Player.class, 6.0f));
        goalSelector.addGoal(7, new RandomLookAroundGoal(this));
    }

    public Role getRole() {
        return Role.values()[Mth.clamp(entityData.get(DATA_ROLE), 0, Role.values().length - 1)];
    }

    public void setRole(Role role) {
        entityData.set(DATA_ROLE, role.ordinal());
        hint = null;
        refreshName();
    }

    /** Short status shown after the role on the name tag, e.g. what the kitchen is missing. */
    public void setHint(@Nullable Component newHint) {
        if (Objects.equals(hint, newHint)) return;
        hint = newHint;
        refreshName();
    }

    private void refreshName() {
        Component name = Component.translatable("cutecafe.role." + getRole().name().toLowerCase());
        if (unpaidPeriods > 0) {
            name = Component.translatable("cutecafe.staff.hint", name, Component.translatable("cutecafe.staff.unpaid"));
        }
        if (hint != null) name = Component.translatable("cutecafe.staff.hint", name, hint);
        setCustomName(name);
        setCustomNameVisible(true);
    }

    /** Hired helpers get a wage; spawn-egg helpers are free volunteers. */
    public void setHired(boolean hired) {
        this.hired = hired;
        this.wageTimer = 0;
        this.unpaidPeriods = 0;
    }

    private void payWage() {
        BlockPos regPos = CashRegisters.nearest(level(), blockPosition(), 48);
        boolean paid = regPos != null
                && level().getBlockEntity(regPos) instanceof CashRegisterBlockEntity register
                && register.withdraw(getRole().wage());
        if (paid) {
            if (unpaidPeriods > 0) {
                unpaidPeriods = 0;
                refreshName();
            }
            if (level() instanceof ServerLevel sl) {
                sl.sendParticles(ParticleTypes.HAPPY_VILLAGER, getX(), getY() + 1.2, getZ(), 5, 0.3, 0.3, 0.3, 0.0);
            }
            return;
        }
        unpaidPeriods++;
        refreshName();
        if (unpaidPeriods >= MAX_MISSED_PAYS) quit();
    }

    private void quit() {
        Component role = Component.translatable("cutecafe.role." + getRole().name().toLowerCase());
        for (Player p : level().getEntitiesOfClass(Player.class, getBoundingBox().inflate(48))) {
            p.displayClientMessage(Component.translatable("cutecafe.staff.quit", role), false);
        }
        if (level() instanceof ServerLevel sl) {
            sl.sendParticles(ParticleTypes.SMOKE, getX(), getY() + 1.0, getZ(), 12, 0.3, 0.5, 0.3, 0.02);
        }
        discard();
    }

    /** Test helper: sneak + empty hand on a helper cycles its role. */
    @Override
    protected InteractionResult mobInteract(Player player, InteractionHand hand) {
        if (player.isShiftKeyDown() && player.getItemInHand(hand).isEmpty()) {
            if (!level().isClientSide) setRole(getRole().next());
            return InteractionResult.sidedSuccess(level().isClientSide);
        }
        return InteractionResult.PASS;
    }

    @Override
    public void tick() {
        super.tick();
        if (level().isClientSide) return;
        if (tickCount == 1 && !hasCustomName()) refreshName();
        if (hired && ++wageTimer >= PAY_PERIOD) {
            wageTimer = 0;
            payWage();
        }
    }

    @Override
    public void remove(RemovalReason reason) {
        OrderBoard.releaseAll(getUUID()); // never leave an order stuck on a missing worker
        super.remove(reason);
    }

    @Override
    public boolean removeWhenFarAway(double distance) {
        return false;
    }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putString("Role", getRole().name());
        tag.putBoolean("Hired", hired);
        tag.putInt("WageTimer", wageTimer);
        tag.putInt("Unpaid", unpaidPeriods);
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        hired = tag.getBoolean("Hired");
        wageTimer = tag.getInt("WageTimer");
        unpaidPeriods = tag.getInt("Unpaid");
        setItemInHand(InteractionHand.MAIN_HAND, ItemStack.EMPTY); // no half-finished dish after a reload
        try {
            entityData.set(DATA_ROLE, Role.valueOf(tag.getString("Role")).ordinal());
        } catch (IllegalArgumentException ignored) {
        }
    }
}
