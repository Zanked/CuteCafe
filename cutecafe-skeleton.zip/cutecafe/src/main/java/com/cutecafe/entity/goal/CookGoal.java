package com.cutecafe.entity.goal;

import com.cutecafe.dish.DishManager;
import com.cutecafe.entity.StaffEntity;
import com.cutecafe.food.CookingPlan;
import com.cutecafe.food.StationType;
import com.cutecafe.order.Order;
import com.cutecafe.order.OrderBoard;
import com.cutecafe.registry.ModBlocks;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.Block;

import javax.annotation.Nullable;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

/**
 * COOK: takes a waiting order, works out the recipe chain, then walks the kitchen:
 * ingredient crates -> cutting board / prep table / oven / grill ... -> serving counter.
 * If the kitchen is missing something, the cook's name tag says what.
 */
public class CookGoal extends StaffTaskGoal {
    private enum Phase { GOING, WORKING, TO_COUNTER }

    private Order candidate;
    private CookingPlan candidatePlan;
    private Map<Block, BlockPos> spots = Map.of();
    @Nullable private BlockPos counter;

    private Order order;
    private CookingPlan plan;
    private Phase phase = Phase.GOING;
    private int stepIndex;
    private int work;

    public CookGoal(StaffEntity staff) {
        super(staff);
    }

    @Override
    public boolean canUse() {
        if (staff.getRole() != StaffEntity.Role.COOK) return false;
        if (!OrderBoard.hasWaiting()) {
            staff.setHint(null);
            return false;
        }
        if (cooldown-- > 0) return false;
        cooldown = 20;

        spots = StationFinder.scan(staff.level(), staff.blockPosition(), 20, 4, kitchenBlocks());
        counter = spots.get(ModBlocks.SERVING_COUNTER.get());

        Component firstProblem = null;
        for (Order o : OrderBoard.waitingOrders()) {
            CookingPlan p = DishManager.INSTANCE.get(o.dish)
                    .map(d -> CookingPlan.forItem(d.result()))
                    .orElse(CookingPlan.invalid());
            Component problem = problemWith(p);
            if (problem == null) {
                candidate = o;
                candidatePlan = p;
                staff.setHint(null);
                return true;
            }
            if (firstProblem == null) firstProblem = problem;
        }
        candidate = null;
        staff.setHint(firstProblem);
        return false;
    }

    /** What the kitchen lacks for this plan, or null if everything needed is in reach. */
    @Nullable
    private Component problemWith(CookingPlan p) {
        if (!p.isValid()) return Component.translatable("cutecafe.staff.no_recipe");
        if (counter == null) return Component.translatable("cutecafe.staff.missing", ModBlocks.SERVING_COUNTER.get().getName());
        for (Block b : p.requiredBlocks()) {
            if (!spots.containsKey(b)) return Component.translatable("cutecafe.staff.missing", b.getName());
        }
        return null;
    }

    private static Set<Block> kitchenBlocks() {
        Set<Block> blocks = new HashSet<>();
        blocks.add(ModBlocks.SERVING_COUNTER.get());
        for (StationType t : StationType.values()) blocks.add(ModBlocks.STATIONS.get(t).get());
        ModBlocks.CRATES.values().forEach(c -> blocks.add(c.get()));
        return blocks;
    }

    @Override
    public void start() {
        resetTask();
        order = null;
        if (candidate == null || !OrderBoard.claim(candidate, staff.getUUID())) {
            done = true;
            return;
        }
        order = candidate;
        plan = candidatePlan;
        stepIndex = 0;
        work = 0;
        phase = Phase.GOING;
    }

    @Override
    public boolean canContinueToUse() {
        return !done && !failed && order != null && OrderBoard.isActive(order);
    }

    @Override
    public void tick() {
        switch (phase) {
            case GOING -> {
                CookingPlan.Step step = plan.steps().get(stepIndex);
                BlockPos target = spots.get(step.block());
                if (target == null) {
                    failed = true;
                    return;
                }
                lookAt(target);
                if (walkTo(target)) {
                    phase = Phase.WORKING;
                    work = 0;
                    resetMove();
                }
            }
            case WORKING -> {
                CookingPlan.Step step = plan.steps().get(stepIndex);
                BlockPos target = spots.get(step.block());
                if (target == null) {
                    failed = true;
                    return;
                }
                lookAt(target);
                work++;
                if (work == 1 || work % 20 == 0) staff.swing(InteractionHand.MAIN_HAND);
                if (!step.isFetch() && work % 10 == 0 && staff.level() instanceof ServerLevel sl) {
                    sl.sendParticles(ParticleTypes.SMOKE,
                            target.getX() + 0.5, target.getY() + 1.1, target.getZ() + 0.5, 2, 0.15, 0.05, 0.15, 0.01);
                }
                if (work >= step.workTicks()) {
                    // The cook now carries whatever this step produced
                    staff.setItemInHand(InteractionHand.MAIN_HAND,
                            new ItemStack(BuiltInRegistries.ITEM.get(step.resultId())));
                    stepIndex++;
                    phase = stepIndex >= plan.steps().size() ? Phase.TO_COUNTER : Phase.GOING;
                    resetMove();
                }
            }
            case TO_COUNTER -> {
                if (counter == null) {
                    failed = true;
                    return;
                }
                lookAt(counter);
                if (walkTo(counter)) {
                    order.status = Order.Status.READY;
                    order.worker = null;
                    staff.setItemInHand(InteractionHand.MAIN_HAND, ItemStack.EMPTY);
                    finished = true;
                    done = true;
                }
            }
        }
    }

    @Override
    public void stop() {
        if (order != null && !finished) {
            OrderBoard.release(order); // gave up: someone else can cook it
            staff.setItemInHand(InteractionHand.MAIN_HAND, ItemStack.EMPTY);
        }
        order = null;
    }
}
