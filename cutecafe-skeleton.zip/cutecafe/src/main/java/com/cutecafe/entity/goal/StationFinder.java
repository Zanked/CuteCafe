package com.cutecafe.entity.goal;

import net.minecraft.core.BlockPos;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import javax.annotation.Nullable;

public class StationFinder {
    /** One pass over the area: the nearest position of each wanted block type. */
    public static Map<Block, BlockPos> scan(Level level, BlockPos origin, int radiusH, int radiusV, Set<Block> wanted) {
        Map<Block, BlockPos> best = new HashMap<>();
        Map<Block, Double> bestDist = new HashMap<>();
        for (BlockPos p : BlockPos.betweenClosed(
                origin.offset(-radiusH, -radiusV, -radiusH), origin.offset(radiusH, radiusV, radiusH))) {
            if (!level.hasChunkAt(p)) continue;
            Block b = level.getBlockState(p).getBlock();
            if (!wanted.contains(b)) continue;
            double d = p.distSqr(origin);
            Double prev = bestDist.get(b);
            if (prev == null || d < prev) {
                bestDist.put(b, d);
                best.put(b, p.immutable());
            }
        }
        return best;
    }

    /** Nearest block of the given type within a box around origin, or null. */
    @Nullable
    public static BlockPos nearest(Level level, BlockPos origin, Block block, int radiusH, int radiusV) {
        BlockPos best = null;
        double bestDist = Double.MAX_VALUE;
        for (BlockPos p : BlockPos.betweenClosed(
                origin.offset(-radiusH, -radiusV, -radiusH), origin.offset(radiusH, radiusV, radiusH))) {
            if (level.getBlockState(p).is(block)) {
                double d = p.distSqr(origin);
                if (d < bestDist) {
                    bestDist = d;
                    best = p.immutable();
                }
            }
        }
        return best;
    }
}
