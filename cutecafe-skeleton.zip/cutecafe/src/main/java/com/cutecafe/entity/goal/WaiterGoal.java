package com.cutecafe.entity.goal;

import com.cutecafe.entity.CustomerEntity;
import com.cutecafe.entity.StaffEntity;
import com.cutecafe.order.Order;
import com.cutecafe.order.OrderBoard;
import com.cutecafe.registry.ModBlocks;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.item.ItemStack;

/** WAITER: pick a finished dish up from the serving counter and bring it to the customer's table. */
public class WaiterGoal extends StaffTaskGoal {
    private enum Phase { TO_COUNTER, TO_TABLE }

    private Order order;
    private BlockPos counter;
    private Phase phase = Phase.TO_COUNTER;

    public WaiterGoal(StaffEntity staff) {
        super(staff);
    }

    @Override
    public boolean canUse() {
        if (staff.getRole() != StaffEntity.Role.WAITER || !OrderBoard.hasReady()) return false;
        if (cooldown-- > 0) return false;
        cooldown = 10;
        counter = StationFinder.nearest(staff.level(), staff.blockPosition(), ModBlocks.SERVING_COUNTER.get(), 20, 4);
        return counter != null;
    }

    @Override
    public void start() {
        resetTask();
        phase = Phase.TO_COUNTER;
        order = OrderBoard.claimReady(staff.getUUID());
        if (order == null) done = true;
    }

    @Override
    public boolean canContinueToUse() {
        return !done && !failed && order != null && OrderBoard.isActive(order);
    }

    @Override
    public void tick() {
        switch (phase) {
            case TO_COUNTER -> {
                if (walkTo(counter)) {
                    staff.setItemInHand(InteractionHand.MAIN_HAND, dishStack(order.dish));
                    phase = Phase.TO_TABLE;
                    resetMove();
                }
            }
            case TO_TABLE -> {
                lookAt(order.table);
                if (walkTo(order.table)) {
                    staff.swing(InteractionHand.MAIN_HAND);
                    if (staff.level() instanceof ServerLevel sl && sl.getEntity(order.customer) instanceof CustomerEntity c) {
                        c.receiveDish(null);
                    }
                    finished = true;
                    done = true;
                }
            }
        }
    }

    @Override
    public void stop() {
        if (order != null && !finished) OrderBoard.release(order);
        staff.setItemInHand(InteractionHand.MAIN_HAND, ItemStack.EMPTY);
        order = null;
    }
}
