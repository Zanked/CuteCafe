package com.cutecafe.entity.goal;

import com.cutecafe.block.CashRegisterBlockEntity;
import com.cutecafe.entity.StaffEntity;
import com.cutecafe.menu.CashRegisters;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

import javax.annotation.Nullable;
import java.util.List;

/** CASHIER: collects the payments customers left on the floor and puts them into the cash register. */
public class CashierGoal extends StaffTaskGoal {
    private enum Phase { TO_COINS, TO_REGISTER }

    private ItemEntity coins;
    private BlockPos register;
    private Phase phase = Phase.TO_COINS;
    private int carried;

    public CashierGoal(StaffEntity staff) {
        super(staff);
    }

    @Nullable
    private ItemEntity nearestCoins(double radiusH, double radiusV) {
        List<ItemEntity> found = staff.level().getEntitiesOfClass(ItemEntity.class,
                staff.getBoundingBox().inflate(radiusH, radiusV, radiusH),
                e -> e.isAlive() && e.getItem().is(Items.EMERALD));
        ItemEntity best = null;
        double bestDist = Double.MAX_VALUE;
        for (ItemEntity e : found) {
            double d = staff.distanceToSqr(e);
            if (d < bestDist) {
                bestDist = d;
                best = e;
            }
        }
        return best;
    }

    @Override
    public boolean canUse() {
        if (staff.getRole() != StaffEntity.Role.CASHIER) return false;
        if (cooldown-- > 0) return false;
        cooldown = 10;
        register = CashRegisters.nearest(staff.level(), staff.blockPosition(), 48);
        if (register == null) return false;
        coins = nearestCoins(24, 6);
        return coins != null;
    }

    @Override
    public void start() {
        resetTask();
        phase = Phase.TO_COINS;
        carried = 0;
    }

    @Override
    public boolean canContinueToUse() {
        return !done && !failed;
    }

    @Override
    public void tick() {
        switch (phase) {
            case TO_COINS -> {
                if (coins == null || !coins.isAlive()) { // someone else got them
                    if (carried > 0) phase = Phase.TO_REGISTER;
                    else done = true;
                    return;
                }
                if (walkToEntity(coins)) {
                    carried += coins.getItem().getCount();
                    coins.discard();
                    staff.swing(InteractionHand.MAIN_HAND);
                    staff.setItemInHand(InteractionHand.MAIN_HAND, new ItemStack(Items.EMERALD, Math.min(64, carried)));
                    coins = nearestCoins(6, 3); // grab any other coins lying close by
                    if (coins == null) {
                        phase = Phase.TO_REGISTER;
                        resetMove();
                    }
                }
            }
            case TO_REGISTER -> {
                lookAt(register);
                if (walkTo(register)) {
                    if (staff.level().getBlockEntity(register) instanceof CashRegisterBlockEntity be) {
                        be.deposit(carried);
                        carried = 0;
                        staff.swing(InteractionHand.MAIN_HAND);
                        staff.level().playSound(null, register, SoundEvents.EXPERIENCE_ORB_PICKUP, SoundSource.BLOCKS, 1.0f, 1.0f);
                        finished = true;
                    }
                    done = true; // register gone: stop() drops the coins
                }
            }
        }
    }

    @Override
    public void stop() {
        if (carried > 0 && staff.level() instanceof ServerLevel) {
            staff.spawnAtLocation(new ItemStack(Items.EMERALD, carried)); // gave up: don't lose the money
            carried = 0;
        }
        staff.setItemInHand(InteractionHand.MAIN_HAND, ItemStack.EMPTY);
        coins = null;
    }
}
