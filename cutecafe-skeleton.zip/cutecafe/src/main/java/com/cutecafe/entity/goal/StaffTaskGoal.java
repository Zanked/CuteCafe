package com.cutecafe.entity.goal;

import com.cutecafe.dish.DishManager;
import com.cutecafe.entity.StaffEntity;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.item.ItemStack;

import java.util.EnumSet;

/** Shared helpers for goals where a helper walks between stations. */
public abstract class StaffTaskGoal extends Goal {
    protected final StaffEntity staff;
    protected boolean failed;
    protected boolean done;
    protected boolean finished;
    protected int cooldown;
    private int stuck;

    protected StaffTaskGoal(StaffEntity staff) {
        this.staff = staff;
        setFlags(EnumSet.of(Flag.MOVE, Flag.LOOK));
    }

    protected boolean isNear(BlockPos p) {
        return staff.distanceToSqr(p.getX() + 0.5, p.getY(), p.getZ() + 0.5) < 6.25;
    }

    /** Walks toward p. Returns true once close enough; sets failed if the path keeps breaking. */
    protected boolean walkTo(BlockPos p) {
        if (isNear(p)) {
            stuck = 0;
            staff.getNavigation().stop();
            return true;
        }
        if (staff.getNavigation().isDone()) {
            if (++stuck > 6) failed = true;
            else staff.getNavigation().moveTo(p.getX() + 0.5, p.getY(), p.getZ() + 0.5, 1.0);
        }
        return false;
    }

    /** Like walkTo, but for a moving target such as a dropped item. */
    protected boolean walkToEntity(Entity target) {
        if (staff.distanceToSqr(target) < 2.5) {
            stuck = 0;
            staff.getNavigation().stop();
            return true;
        }
        if (staff.getNavigation().isDone()) {
            if (++stuck > 6) failed = true;
            else staff.getNavigation().moveTo(target, 1.0);
        }
        return false;
    }

    protected void resetTask() {
        failed = false;
        done = false;
        finished = false;
        stuck = 0;
    }

    protected void resetMove() {
        stuck = 0;
    }

    protected void lookAt(BlockPos p) {
        staff.getLookControl().setLookAt(p.getX() + 0.5, p.getY() + 0.5, p.getZ() + 0.5);
    }

    protected ItemStack dishStack(ResourceLocation dishId) {
        return DishManager.INSTANCE.get(dishId)
                .map(d -> new ItemStack(BuiltInRegistries.ITEM.get(d.result())))
                .orElse(ItemStack.EMPTY);
    }
}
