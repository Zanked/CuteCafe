package com.cutecafe.entity.goal;

import com.cutecafe.block.TableBlock;
import com.cutecafe.entity.CustomerEntity;
import com.cutecafe.menu.CafeMenu;
import com.cutecafe.order.OrderBoard;
import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.ai.goal.Goal;

import javax.annotation.Nullable;
import java.util.EnumSet;

/** Customer looks for a free table nearby, walks to it and places an order. */
public class GoToTableGoal extends Goal {
    private final CustomerEntity customer;
    @Nullable private BlockPos target;
    private int cooldown;

    public GoToTableGoal(CustomerEntity customer) {
        this.customer = customer;
        setFlags(EnumSet.of(Flag.MOVE));
    }

    @Override
    public boolean canUse() {
        if (customer.hasOrder()) return false;
        if (cooldown-- > 0) return false;
        cooldown = 10;
        if (CafeMenu.available(customer.level(), customer.blockPosition()).isEmpty()) return false;

        BlockPos origin = customer.blockPosition();
        BlockPos best = null;
        double bestDist = Double.MAX_VALUE;
        for (BlockPos p : BlockPos.betweenClosed(origin.offset(-16, -3, -16), origin.offset(16, 3, 16))) {
            if (customer.level().getBlockState(p).getBlock() instanceof TableBlock && !OrderBoard.isTableTaken(p)) {
                double d = p.distSqr(origin);
                if (d < bestDist) {
                    bestDist = d;
                    best = p.immutable();
                }
            }
        }
        target = best;
        return best != null;
    }

    @Override
    public boolean canContinueToUse() {
        return !customer.hasOrder() && target != null;
    }

    @Override
    public void start() {
        moveToTarget();
    }

    @Override
    public void tick() {
        if (target == null) return;
        if (OrderBoard.isTableTaken(target)) { // someone else got it first
            target = null;
            return;
        }
        double dist = customer.distanceToSqr(target.getX() + 0.5, target.getY(), target.getZ() + 0.5);
        if (dist < 6.0) {
            customer.placeOrder(target);
        } else if (customer.getNavigation().isDone()) {
            moveToTarget();
        }
    }

    @Override
    public void stop() {
        target = null;
    }

    private void moveToTarget() {
        if (target != null) {
            customer.getNavigation().moveTo(target.getX() + 0.5, target.getY(), target.getZ() + 0.5, 1.0);
        }
    }
}
