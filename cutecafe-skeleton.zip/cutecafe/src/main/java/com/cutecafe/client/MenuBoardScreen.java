package com.cutecafe.client;

import com.cutecafe.block.MenuBoardBlockEntity;
import com.cutecafe.network.OpenMenuPayload.DishRow;
import com.cutecafe.network.UpdateDishPayload;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.CommonComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.util.Mth;
import net.minecraft.world.item.ItemStack;
import net.neoforged.neoforge.network.PacketDistributor;

import java.util.ArrayList;
import java.util.List;

/** Menu editor: toggle dishes on/off and set prices. Changes are sent to the server immediately. */
public class MenuBoardScreen extends Screen {
    private static final int PER_PAGE = 6;
    private static final int ROW_H = 26;
    private static final int TOP = 44;

    private final BlockPos pos;
    private final List<DishRow> rows;
    private int page;

    public MenuBoardScreen(BlockPos pos, List<DishRow> rows) {
        super(Component.translatable("cutecafe.menu.title"));
        this.pos = pos;
        this.rows = new ArrayList<>(rows);
    }

    private int left() {
        return width / 2 - 122;
    }

    private int pageCount() {
        return Math.max(1, (rows.size() + PER_PAGE - 1) / PER_PAGE);
    }

    @Override
    protected void init() {
        rebuild();
    }

    private void rebuild() {
        clearWidgets();
        int left = left();
        int start = page * PER_PAGE;
        int end = Math.min(rows.size(), start + PER_PAGE);
        for (int i = start; i < end; i++) {
            final int idx = i;
            DishRow row = rows.get(i);
            int y = TOP + (i - start) * ROW_H;
            addRenderableWidget(Button.builder(
                    Component.translatable(row.enabled() ? "cutecafe.menu.on" : "cutecafe.menu.off"),
                    b -> toggle(idx)).bounds(left, y, 40, 20).build());
            if (row.enabled()) {
                addRenderableWidget(Button.builder(Component.literal("-"), b -> changePrice(idx, -1))
                        .bounds(left + 170, y, 16, 20).build());
                addRenderableWidget(Button.builder(Component.literal("+"), b -> changePrice(idx, 1))
                        .bounds(left + 226, y, 16, 20).build());
            }
        }
        int by = TOP + PER_PAGE * ROW_H + 6;
        Button prev = Button.builder(Component.literal("<"), b -> { page--; rebuild(); })
                .bounds(width / 2 - 100, by, 60, 20).build();
        prev.active = page > 0;
        addRenderableWidget(prev);
        addRenderableWidget(Button.builder(CommonComponents.GUI_DONE, b -> onClose())
                .bounds(width / 2 - 30, by, 60, 20).build());
        Button next = Button.builder(Component.literal(">"), b -> { page++; rebuild(); })
                .bounds(width / 2 + 40, by, 60, 20).build();
        next.active = page < pageCount() - 1;
        addRenderableWidget(next);
    }

    private void toggle(int idx) {
        DishRow r = rows.get(idx);
        DishRow n = new DishRow(r.id(), r.result(), !r.enabled(), r.price());
        rows.set(idx, n);
        send(n);
        rebuild();
    }

    private void changePrice(int idx, int delta) {
        int step = hasShiftDown() ? 5 : 1;
        DishRow r = rows.get(idx);
        int price = Mth.clamp(r.price() + delta * step, 1, MenuBoardBlockEntity.MAX_PRICE);
        DishRow n = new DishRow(r.id(), r.result(), r.enabled(), price);
        rows.set(idx, n);
        send(n);
        rebuild();
    }

    private void send(DishRow r) {
        PacketDistributor.sendToServer(new UpdateDishPayload(pos, r.id(), r.enabled(), r.price()));
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        super.render(g, mouseX, mouseY, partialTick); // background is drawn by the caller in 1.21
        g.drawCenteredString(font, title, width / 2, 14, 0xFFFFFF);
        g.drawCenteredString(font, Component.translatable("cutecafe.menu.hint"), width / 2, 28, 0xAAAAAA);

        int left = left();
        int start = page * PER_PAGE;
        int end = Math.min(rows.size(), start + PER_PAGE);
        for (int i = start; i < end; i++) {
            DishRow row = rows.get(i);
            int y = TOP + (i - start) * ROW_H;
            ItemStack stack = new ItemStack(BuiltInRegistries.ITEM.get(row.result()));
            g.renderItem(stack, left + 46, y + 2);
            g.drawString(font, stack.getHoverName(), left + 68, y + 6, row.enabled() ? 0xFFFFFF : 0x777777);
            if (row.enabled()) {
                g.drawCenteredString(font, String.valueOf(row.price()), left + 206, y + 6, 0xFFFFFF);
            }
        }
        g.drawCenteredString(font, (page + 1) + " / " + pageCount(), width / 2, TOP + PER_PAGE * ROW_H + 30, 0xAAAAAA);
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }
}
