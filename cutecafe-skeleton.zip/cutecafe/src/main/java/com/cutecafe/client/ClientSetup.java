package com.cutecafe.client;

import com.cutecafe.CuteCafe;
import com.cutecafe.entity.CustomerEntity;
import com.cutecafe.entity.StaffEntity;
import com.cutecafe.registry.ModEntities;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.EntityRenderersEvent;

@EventBusSubscriber(modid = CuteCafe.MOD_ID, bus = EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class ClientSetup {
    @SubscribeEvent
    public static void registerLayers(EntityRenderersEvent.RegisterLayerDefinitions event) {
        event.registerLayerDefinition(CuteHumanoidModel.LAYER, CuteHumanoidModel::createLayer);
    }

    @SubscribeEvent
    public static void registerRenderers(EntityRenderersEvent.RegisterRenderers event) {
        event.registerEntityRenderer(ModEntities.CUSTOMER.get(),
                ctx -> new CuteHumanoidRenderer<CustomerEntity>(ctx, CuteTextures::customer));
        event.registerEntityRenderer(ModEntities.STAFF.get(),
                ctx -> new CuteHumanoidRenderer<StaffEntity>(ctx, CuteTextures::staff));
    }
}
