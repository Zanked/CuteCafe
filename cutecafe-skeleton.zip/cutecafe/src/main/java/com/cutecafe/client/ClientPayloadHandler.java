package com.cutecafe.client;

import com.cutecafe.network.OpenMenuPayload;
import net.minecraft.client.Minecraft;

public class ClientPayloadHandler {
    public static void openMenu(OpenMenuPayload payload) {
        Minecraft.getInstance().setScreen(new MenuBoardScreen(payload.pos(), payload.rows()));
    }
}
