package com.cutecafe.client;

import com.cutecafe.CuteCafe;
import com.cutecafe.entity.CustomerEntity;
import com.cutecafe.entity.StaffEntity;
import net.minecraft.resources.ResourceLocation;

public class CuteTextures {
    private static final ResourceLocation[] CUSTOMER = new ResourceLocation[CustomerEntity.VARIANTS];
    private static final ResourceLocation[] STAFF = new ResourceLocation[StaffEntity.Role.values().length];

    static {
        for (int i = 0; i < CUSTOMER.length; i++) {
            CUSTOMER[i] = ResourceLocation.fromNamespaceAndPath(CuteCafe.MOD_ID, "textures/entity/customer_" + i + ".png");
        }
        for (StaffEntity.Role role : StaffEntity.Role.values()) {
            STAFF[role.ordinal()] = ResourceLocation.fromNamespaceAndPath(
                    CuteCafe.MOD_ID, "textures/entity/staff_" + role.getSerializedName() + ".png");
        }
    }

    public static ResourceLocation customer(CustomerEntity customer) {
        return CUSTOMER[customer.getVariant()];
    }

    public static ResourceLocation staff(StaffEntity staff) {
        return STAFF[staff.getRole().ordinal()];
    }
}
