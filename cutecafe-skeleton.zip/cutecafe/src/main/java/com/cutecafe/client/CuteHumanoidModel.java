package com.cutecafe.client;

import com.cutecafe.CuteCafe;
import com.cutecafe.entity.StaffEntity;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeDeformation;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.Mob;

/**
 * Chibi proportions (big head, small body), 64x64 texture.
 * Uses the vanilla humanoid part names so walking / arm swinging animations just work.
 *
 * Texture layout (x, y): head 0,0 | hair 0,18 | chef hat 0,36 | visor 34,36 | bow 34,41 |
 * body 0,49 | right arm 22,46 | left arm 32,46 | right leg 22,54 | left leg 36,54
 */
public class CuteHumanoidModel<T extends Mob> extends HumanoidModel<T> {
    public static final ModelLayerLocation LAYER =
            new ModelLayerLocation(ResourceLocation.fromNamespaceAndPath(CuteCafe.MOD_ID, "cute_humanoid"), "main");

    private final ModelPart chefHat;
    private final ModelPart visor;
    private final ModelPart bow;

    public CuteHumanoidModel(ModelPart root) {
        super(root);
        this.chefHat = hat.getChild("chef_hat");
        this.visor = hat.getChild("visor");
        this.bow = body.getChild("bow");
    }

    public static LayerDefinition createLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();

        // Big round head
        root.addOrReplaceChild("head",
                CubeListBuilder.create().texOffs(0, 0).addBox(-5f, -9f, -4.5f, 10f, 9f, 9f),
                PartPose.offset(0f, 12f, 0f));

        // "hat" = hair shell around the head + role accessories (shown or hidden per role)
        PartDefinition hat = root.addOrReplaceChild("hat",
                CubeListBuilder.create().texOffs(0, 18).addBox(-5f, -9f, -4.5f, 10f, 9f, 9f, new CubeDeformation(0.4f)),
                PartPose.offset(0f, 12f, 0f));
        hat.addOrReplaceChild("chef_hat",
                CubeListBuilder.create().texOffs(0, 36).addBox(-4f, -14f, -4f, 8f, 5f, 8f), PartPose.ZERO);
        hat.addOrReplaceChild("visor",
                CubeListBuilder.create().texOffs(34, 36).addBox(-5f, -7f, -7f, 10f, 1f, 3f), PartPose.ZERO);

        // Small body (+ bow tie for waiters)
        PartDefinition body = root.addOrReplaceChild("body",
                CubeListBuilder.create().texOffs(0, 49).addBox(-3f, 0f, -2f, 6f, 7f, 4f),
                PartPose.offset(0f, 12f, 0f));
        body.addOrReplaceChild("bow",
                CubeListBuilder.create().texOffs(34, 41).addBox(-2f, 0.5f, -3f, 4f, 2f, 1f), PartPose.ZERO);

        // Short limbs
        root.addOrReplaceChild("right_arm",
                CubeListBuilder.create().texOffs(22, 46).addBox(-1f, -1f, -1f, 2f, 6f, 2f),
                PartPose.offset(-4f, 13f, 0f));
        root.addOrReplaceChild("left_arm",
                CubeListBuilder.create().texOffs(32, 46).addBox(-1f, -1f, -1f, 2f, 6f, 2f),
                PartPose.offset(4f, 13f, 0f));
        root.addOrReplaceChild("right_leg",
                CubeListBuilder.create().texOffs(22, 54).addBox(-1.5f, 0f, -1.5f, 3f, 5f, 3f),
                PartPose.offset(-1.8f, 19f, 0f));
        root.addOrReplaceChild("left_leg",
                CubeListBuilder.create().texOffs(36, 54).addBox(-1.5f, 0f, -1.5f, 3f, 5f, 3f),
                PartPose.offset(1.8f, 19f, 0f));

        return LayerDefinition.create(mesh, 64, 64);
    }

    @Override
    public void setupAnim(T entity, float limbSwing, float limbSwingAmount, float ageInTicks,
                          float netHeadYaw, float headPitch) {
        super.setupAnim(entity, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch);
        StaffEntity.Role role = entity instanceof StaffEntity staff ? staff.getRole() : null;
        chefHat.visible = role == StaffEntity.Role.COOK;
        visor.visible = role == StaffEntity.Role.CASHIER;
        bow.visible = role == StaffEntity.Role.WAITER;
    }
}
