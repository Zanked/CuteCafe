package com.cutecafe.client;

import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.HumanoidMobRenderer;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.Mob;

import java.util.function.Function;

public class CuteHumanoidRenderer<T extends Mob> extends HumanoidMobRenderer<T, CuteHumanoidModel<T>> {
    private final Function<T, ResourceLocation> textures;

    public CuteHumanoidRenderer(EntityRendererProvider.Context context, Function<T, ResourceLocation> textures) {
        super(context, new CuteHumanoidModel<>(context.bakeLayer(CuteHumanoidModel.LAYER)), 0.35f);
        this.textures = textures;
    }

    @Override
    public ResourceLocation getTextureLocation(T entity) {
        return textures.apply(entity);
    }
}
