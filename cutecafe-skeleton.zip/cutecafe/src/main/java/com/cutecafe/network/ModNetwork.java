package com.cutecafe.network;

import com.cutecafe.block.MenuBoardBlockEntity;
import com.cutecafe.client.ClientPayloadHandler;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.network.event.RegisterPayloadHandlersEvent;
import net.neoforged.neoforge.network.handling.IPayloadContext;
import net.neoforged.neoforge.network.registration.PayloadRegistrar;

public class ModNetwork {
    public static void register(RegisterPayloadHandlersEvent event) {
        PayloadRegistrar registrar = event.registrar("1");
        // The lambda keeps the client-only class from loading on a dedicated server
        registrar.playToClient(OpenMenuPayload.TYPE, OpenMenuPayload.CODEC,
                (payload, ctx) -> ClientPayloadHandler.openMenu(payload));
        registrar.playToServer(UpdateDishPayload.TYPE, UpdateDishPayload.CODEC, ModNetwork::handleUpdate);
    }

    private static void handleUpdate(UpdateDishPayload payload, IPayloadContext ctx) {
        Player player = ctx.player();
        if (player.distanceToSqr(Vec3.atCenterOf(payload.pos())) > 64) return; // must be near the board
        if (player.level().getBlockEntity(payload.pos()) instanceof MenuBoardBlockEntity board) {
            board.setDish(payload.dish(), payload.enabled(), payload.price());
        }
    }
}
