package com.cutecafe.network;

import com.cutecafe.CuteCafe;
import io.netty.buffer.ByteBuf;
import net.minecraft.core.BlockPos;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;

import java.util.List;

/** Server -> client: open the menu editor with the current state of a menu board. */
public record OpenMenuPayload(BlockPos pos, List<DishRow> rows) implements CustomPacketPayload {
    public static final Type<OpenMenuPayload> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath(CuteCafe.MOD_ID, "open_menu"));

    public static final StreamCodec<ByteBuf, OpenMenuPayload> CODEC = StreamCodec.composite(
            BlockPos.STREAM_CODEC, OpenMenuPayload::pos,
            DishRow.CODEC.apply(ByteBufCodecs.list()), OpenMenuPayload::rows,
            OpenMenuPayload::new);

    @Override
    public Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }

    public record DishRow(ResourceLocation id, ResourceLocation result, boolean enabled, int price) {
        public static final StreamCodec<ByteBuf, DishRow> CODEC = StreamCodec.composite(
                ResourceLocation.STREAM_CODEC, DishRow::id,
                ResourceLocation.STREAM_CODEC, DishRow::result,
                ByteBufCodecs.BOOL, DishRow::enabled,
                ByteBufCodecs.VAR_INT, DishRow::price,
                DishRow::new);
    }
}
