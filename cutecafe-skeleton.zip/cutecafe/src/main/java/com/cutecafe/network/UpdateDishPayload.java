package com.cutecafe.network;

import com.cutecafe.CuteCafe;
import io.netty.buffer.ByteBuf;
import net.minecraft.core.BlockPos;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;

/** Client -> server: change one dish on a menu board (on/off and price). */
public record UpdateDishPayload(BlockPos pos, ResourceLocation dish, boolean enabled, int price)
        implements CustomPacketPayload {
    public static final Type<UpdateDishPayload> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath(CuteCafe.MOD_ID, "update_dish"));

    public static final StreamCodec<ByteBuf, UpdateDishPayload> CODEC = StreamCodec.composite(
            BlockPos.STREAM_CODEC, UpdateDishPayload::pos,
            ResourceLocation.STREAM_CODEC, UpdateDishPayload::dish,
            ByteBufCodecs.BOOL, UpdateDishPayload::enabled,
            ByteBufCodecs.VAR_INT, UpdateDishPayload::price,
            UpdateDishPayload::new);

    @Override
    public Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }
}
