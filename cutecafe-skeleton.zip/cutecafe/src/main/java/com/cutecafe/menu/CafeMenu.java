package com.cutecafe.menu;

import com.cutecafe.block.MenuBoardBlockEntity;
import com.cutecafe.dish.Dish;
import com.cutecafe.dish.DishManager;
import net.minecraft.core.BlockPos;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.Level;

import java.util.ArrayList;
import java.util.List;

public class CafeMenu {
    public static final double BOARD_RANGE = 32;

    public record Entry(ResourceLocation id, int price) {}

    /**
     * Dishes customers can order near origin. If a menu board is nearby, only its enabled dishes
     * (with its prices). With no board at all, every dish at its default price.
     */
    public static List<Entry> available(Level level, BlockPos origin) {
        BlockPos boardPos = MenuBoards.nearest(level, origin, BOARD_RANGE);
        if (boardPos != null && level.getBlockEntity(boardPos) instanceof MenuBoardBlockEntity board) {
            return board.entries();
        }
        List<Entry> all = new ArrayList<>();
        for (ResourceLocation id : DishManager.INSTANCE.allIds()) {
            DishManager.INSTANCE.get(id).ifPresent((Dish d) -> all.add(new Entry(id, d.price())));
        }
        return all;
    }
}
