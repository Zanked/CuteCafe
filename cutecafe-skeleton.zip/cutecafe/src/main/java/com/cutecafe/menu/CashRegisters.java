package com.cutecafe.menu;

import net.minecraft.core.BlockPos;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.level.Level;

import javax.annotation.Nullable;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

/** Server-side index of loaded cash registers, so helpers can find one cheaply. */
public class CashRegisters {
    private static final Map<ResourceKey<Level>, Set<BlockPos>> REGISTERS = new HashMap<>();

    public static void add(Level level, BlockPos pos) {
        REGISTERS.computeIfAbsent(level.dimension(), k -> new HashSet<>()).add(pos.immutable());
    }

    public static void remove(Level level, BlockPos pos) {
        Set<BlockPos> set = REGISTERS.get(level.dimension());
        if (set != null) set.remove(pos);
    }

    @Nullable
    public static BlockPos nearest(Level level, BlockPos origin, double range) {
        Set<BlockPos> set = REGISTERS.get(level.dimension());
        if (set == null) return null;
        BlockPos best = null;
        double bestDist = range * range;
        for (BlockPos p : set) {
            double d = p.distSqr(origin);
            if (d <= bestDist) {
                bestDist = d;
                best = p;
            }
        }
        return best;
    }

    public static void clear() {
        REGISTERS.clear();
    }
}
