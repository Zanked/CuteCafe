package com.cutecafe.menu;

import net.minecraft.core.BlockPos;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.level.Level;

import javax.annotation.Nullable;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

/** Server-side index of loaded menu boards, so customers can find one without scanning blocks. */
public class MenuBoards {
    private static final Map<ResourceKey<Level>, Set<BlockPos>> BOARDS = new HashMap<>();

    public static void add(Level level, BlockPos pos) {
        BOARDS.computeIfAbsent(level.dimension(), k -> new HashSet<>()).add(pos.immutable());
    }

    public static void remove(Level level, BlockPos pos) {
        Set<BlockPos> set = BOARDS.get(level.dimension());
        if (set != null) set.remove(pos);
    }

    @Nullable
    public static BlockPos nearest(Level level, BlockPos origin, double range) {
        Set<BlockPos> set = BOARDS.get(level.dimension());
        if (set == null) return null;
        BlockPos best = null;
        double bestDist = range * range;
        for (BlockPos p : set) {
            double d = p.distSqr(origin);
            if (d <= bestDist) {
                bestDist = d;
                best = p;
            }
        }
        return best;
    }

    public static void clear() {
        BOARDS.clear();
    }
}
