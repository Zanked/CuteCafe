package com.cutecafe.order;

import net.minecraft.core.BlockPos;

import javax.annotation.Nullable;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/**
 * Shared order queue. Customers post orders, cooks claim WAITING ones,
 * waiters claim READY ones. In-memory only for now (customers re-post
 * their order when they load back in).
 */
public class OrderBoard {
    private static final List<Order> ORDERS = new ArrayList<>();

    public static void add(Order order) {
        remove(order.customer);
        ORDERS.add(order);
    }

    public static void remove(UUID customer) {
        ORDERS.removeIf(o -> o.customer.equals(customer));
    }

    public static boolean isTableTaken(BlockPos table) {
        return ORDERS.stream().anyMatch(o -> o.table.equals(table));
    }

    /** True while this exact order object is still on the board. */
    public static boolean isActive(Order order) {
        return ORDERS.contains(order);
    }

    public static boolean hasWaiting() {
        return ORDERS.stream().anyMatch(o -> o.status == Order.Status.WAITING);
    }

    public static boolean hasReady() {
        return ORDERS.stream().anyMatch(o -> o.status == Order.Status.READY);
    }

    /** Snapshot of all orders nobody has taken yet, oldest first. */
    public static List<Order> waitingOrders() {
        return ORDERS.stream().filter(o -> o.status == Order.Status.WAITING).toList();
    }

    /** Cook takes this specific waiting order. */
    public static boolean claim(Order order, UUID worker) {
        if (!ORDERS.contains(order) || order.status != Order.Status.WAITING) return false;
        order.status = Order.Status.COOKING;
        order.worker = worker;
        return true;
    }

    /** Cook takes the oldest waiting order. */
    @Nullable
    public static Order claimWaiting(UUID worker) {
        for (Order o : ORDERS) {
            if (o.status == Order.Status.WAITING) {
                o.status = Order.Status.COOKING;
                o.worker = worker;
                return o;
            }
        }
        return null;
    }

    /** Waiter takes the oldest finished order. */
    @Nullable
    public static Order claimReady(UUID worker) {
        for (Order o : ORDERS) {
            if (o.status == Order.Status.READY) {
                o.status = Order.Status.DELIVERING;
                o.worker = worker;
                return o;
            }
        }
        return null;
    }

    /** A worker disappeared (quit, died, unloaded): hand all its orders back. */
    public static void releaseAll(UUID worker) {
        for (Order o : ORDERS) {
            if (worker.equals(o.worker)) release(o);
        }
    }

    /** Worker gave up: put the order back so someone else can take it. */
    public static void release(Order order) {
        if (!ORDERS.contains(order)) return;
        order.worker = null;
        if (order.status == Order.Status.COOKING) order.status = Order.Status.WAITING;
        else if (order.status == Order.Status.DELIVERING) order.status = Order.Status.READY;
    }

    public static void clear() {
        ORDERS.clear();
    }
}
