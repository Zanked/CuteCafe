package com.cutecafe.order;

import net.minecraft.core.BlockPos;
import net.minecraft.resources.ResourceLocation;

import javax.annotation.Nullable;
import java.util.UUID;

public class Order {
    /** WAITING -> COOKING (claimed by cook) -> READY (on counter) -> DELIVERING (claimed by waiter) */
    public enum Status { WAITING, COOKING, READY, DELIVERING }

    public final UUID customer;
    public final ResourceLocation dish;
    public final BlockPos table;
    public Status status = Status.WAITING;
    /** Staff member currently working on this order. */
    @Nullable public UUID worker;

    public Order(UUID customer, ResourceLocation dish, BlockPos table) {
        this.customer = customer;
        this.dish = dish;
        this.table = table;
    }
}
