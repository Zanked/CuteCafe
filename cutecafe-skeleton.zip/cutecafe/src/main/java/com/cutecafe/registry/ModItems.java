package com.cutecafe.registry;

import com.cutecafe.CuteCafe;
import com.cutecafe.food.FoodIds;
import com.cutecafe.food.StationType;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.neoforged.neoforge.common.DeferredSpawnEggItem;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredRegister;

import java.util.EnumMap;
import java.util.LinkedHashMap;
import java.util.Map;

public class ModItems {
    public static final DeferredRegister.Items ITEMS = DeferredRegister.createItems(CuteCafe.MOD_ID);

    public static final DeferredItem<BlockItem> TABLE = ITEMS.register("table",
            () -> new BlockItem(ModBlocks.TABLE.get(), new Item.Properties()));
    public static final DeferredItem<BlockItem> SERVING_COUNTER = ITEMS.register("serving_counter",
            () -> new BlockItem(ModBlocks.SERVING_COUNTER.get(), new Item.Properties()));
    public static final DeferredItem<BlockItem> STOVE = ITEMS.register("stove",
            () -> new BlockItem(ModBlocks.STOVE.get(), new Item.Properties()));

    public static final DeferredItem<BlockItem> MENU_BOARD = ITEMS.register("menu_board",
            () -> new BlockItem(ModBlocks.MENU_BOARD.get(), new Item.Properties()));

    // Spawn eggs for testing until real customer spawning is implemented
    public static final DeferredItem<DeferredSpawnEggItem> CUSTOMER_SPAWN_EGG = ITEMS.register("customer_spawn_egg",
            () -> new DeferredSpawnEggItem(ModEntities.CUSTOMER, 0xF7C6D9, 0xFFFFFF, new Item.Properties()));
    public static final DeferredItem<DeferredSpawnEggItem> STAFF_SPAWN_EGG = ITEMS.register("staff_spawn_egg",
            () -> new DeferredSpawnEggItem(ModEntities.STAFF, 0xBFE3D0, 0xFFFFFF, new Item.Properties()));

    public static final DeferredItem<BlockItem> CAFE_ENTRANCE = ITEMS.register("cafe_entrance",
            () -> new BlockItem(ModBlocks.CAFE_ENTRANCE.get(), new Item.Properties()));
    public static final DeferredItem<BlockItem> JOB_BOARD = ITEMS.register("job_board",
            () -> new BlockItem(ModBlocks.JOB_BOARD.get(), new Item.Properties()));

    public static final DeferredItem<BlockItem> CASH_REGISTER = ITEMS.register("cash_register",
            () -> new BlockItem(ModBlocks.CASH_REGISTER.get(), new Item.Properties()));

    /** All custom food: ingredients, intermediates and finished dishes. */
    public static final Map<String, DeferredItem<Item>> FOOD = new LinkedHashMap<>();
    public static final Map<String, DeferredItem<BlockItem>> CRATE_ITEMS = new LinkedHashMap<>();
    public static final Map<StationType, DeferredItem<BlockItem>> STATION_ITEMS = new EnumMap<>(StationType.class);

    static {
        for (String id : FoodIds.ALL) {
            FOOD.put(id, ITEMS.register(id, () -> new Item(new Item.Properties())));
        }
        for (String ingredient : FoodIds.INGREDIENTS) {
            CRATE_ITEMS.put(ingredient, ITEMS.register("crate_" + ingredient,
                    () -> new BlockItem(ModBlocks.CRATES.get(ingredient).get(), new Item.Properties())));
        }
        for (StationType type : StationType.values()) {
            STATION_ITEMS.put(type, ITEMS.register(type.getSerializedName(),
                    () -> new BlockItem(ModBlocks.STATIONS.get(type).get(), new Item.Properties())));
        }
    }
}
