package com.cutecafe.registry;

import com.cutecafe.CuteCafe;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.ItemStack;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

public class ModCreativeTabs {
    public static final DeferredRegister<CreativeModeTab> TABS =
            DeferredRegister.create(Registries.CREATIVE_MODE_TAB, CuteCafe.MOD_ID);

    public static final DeferredHolder<CreativeModeTab, CreativeModeTab> MAIN = TABS.register("main",
            () -> CreativeModeTab.builder()
                    .title(Component.translatable("itemGroup.cutecafe"))
                    .icon(() -> new ItemStack(ModItems.TABLE.get()))
                    .displayItems((params, output) -> {
                        output.accept(ModItems.TABLE.get());
                        output.accept(ModItems.SERVING_COUNTER.get());
                        output.accept(ModItems.MENU_BOARD.get());
                        output.accept(ModItems.CAFE_ENTRANCE.get());
                        output.accept(ModItems.JOB_BOARD.get());
                        output.accept(ModItems.CASH_REGISTER.get());
                        ModItems.STATION_ITEMS.values().forEach(i -> output.accept(i.get()));
                        ModItems.CRATE_ITEMS.values().forEach(i -> output.accept(i.get()));
                        ModItems.FOOD.values().forEach(i -> output.accept(i.get()));
                        output.accept(ModItems.CUSTOMER_SPAWN_EGG.get());
                        output.accept(ModItems.STAFF_SPAWN_EGG.get());
                    })
                    .build());
}
