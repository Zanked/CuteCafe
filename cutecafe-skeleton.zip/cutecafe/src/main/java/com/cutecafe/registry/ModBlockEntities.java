package com.cutecafe.registry;

import com.cutecafe.CuteCafe;
import com.cutecafe.block.CashRegisterBlockEntity;
import com.cutecafe.block.MenuBoardBlockEntity;
import com.cutecafe.block.StationBlockEntity;
import net.minecraft.core.registries.Registries;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.neoforged.neoforge.registries.DeferredBlock;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

public class ModBlockEntities {
    public static final DeferredRegister<BlockEntityType<?>> BLOCK_ENTITIES =
            DeferredRegister.create(Registries.BLOCK_ENTITY_TYPE, CuteCafe.MOD_ID);

    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<MenuBoardBlockEntity>> MENU_BOARD =
            BLOCK_ENTITIES.register("menu_board", () -> BlockEntityType.Builder
                    .of(MenuBoardBlockEntity::new, ModBlocks.MENU_BOARD.get()).build(null));

    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<StationBlockEntity>> STATION =
            BLOCK_ENTITIES.register("station", () -> BlockEntityType.Builder
                    .of(StationBlockEntity::new,
                            ModBlocks.STATIONS.values().stream().map(DeferredBlock::get).toArray(Block[]::new))
                    .build(null));

    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<CashRegisterBlockEntity>> CASH_REGISTER =
            BLOCK_ENTITIES.register("cash_register", () -> BlockEntityType.Builder
                    .of(CashRegisterBlockEntity::new, ModBlocks.CASH_REGISTER.get()).build(null));
}
