package com.cutecafe.registry;

import com.cutecafe.CuteCafe;
import com.cutecafe.block.CafeEntranceBlock;
import com.cutecafe.block.CashRegisterBlock;
import com.cutecafe.block.IngredientCrateBlock;
import com.cutecafe.block.JobBoardBlock;
import com.cutecafe.block.MenuBoardBlock;
import com.cutecafe.block.StationBlock;
import com.cutecafe.food.FoodIds;
import com.cutecafe.food.StationType;
import net.minecraft.resources.ResourceLocation;
import com.cutecafe.block.TableBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.material.MapColor;
import net.neoforged.neoforge.registries.DeferredBlock;
import net.neoforged.neoforge.registries.DeferredRegister;

import java.util.EnumMap;
import java.util.LinkedHashMap;
import java.util.Map;

public class ModBlocks {
    public static final DeferredRegister.Blocks BLOCKS = DeferredRegister.createBlocks(CuteCafe.MOD_ID);

    public static final DeferredBlock<TableBlock> TABLE = BLOCKS.register("table",
            () -> new TableBlock(BlockBehaviour.Properties.of()
                    .mapColor(MapColor.WOOD).strength(1.5f).sound(SoundType.WOOD)));

    public static final DeferredBlock<Block> SERVING_COUNTER = BLOCKS.register("serving_counter",
            () -> new Block(BlockBehaviour.Properties.of()
                    .mapColor(MapColor.WOOD).strength(1.5f).sound(SoundType.WOOD)));

    public static final DeferredBlock<MenuBoardBlock> MENU_BOARD = BLOCKS.register("menu_board",
            () -> new MenuBoardBlock(BlockBehaviour.Properties.of()
                    .mapColor(MapColor.WOOD).strength(1.5f).sound(SoundType.WOOD)));

    public static final DeferredBlock<CafeEntranceBlock> CAFE_ENTRANCE = BLOCKS.register("cafe_entrance",
            () -> new CafeEntranceBlock(BlockBehaviour.Properties.of()
                    .mapColor(MapColor.WOOD).strength(1.5f).sound(SoundType.WOOD)));

    public static final DeferredBlock<JobBoardBlock> JOB_BOARD = BLOCKS.register("job_board",
            () -> new JobBoardBlock(BlockBehaviour.Properties.of()
                    .mapColor(MapColor.WOOD).strength(1.5f).sound(SoundType.WOOD)));

    public static final DeferredBlock<CashRegisterBlock> CASH_REGISTER = BLOCKS.register("cash_register",
            () -> new CashRegisterBlock(BlockBehaviour.Properties.of()
                    .mapColor(MapColor.METAL).strength(2.0f).sound(SoundType.METAL)));

    public static final DeferredBlock<Block> STOVE = BLOCKS.register("stove",
            () -> new Block(BlockBehaviour.Properties.of()
                    .mapColor(MapColor.STONE).strength(2.0f).sound(SoundType.STONE)));

    /** Cutting board, prep table, oven, grill, rice cooker. */
    public static final Map<StationType, DeferredBlock<StationBlock>> STATIONS = new EnumMap<>(StationType.class);
    /** Endless supply crates, one per raw ingredient. */
    public static final Map<String, DeferredBlock<IngredientCrateBlock>> CRATES = new LinkedHashMap<>();

    static {
        for (StationType type : StationType.values()) {
            STATIONS.put(type, BLOCKS.register(type.getSerializedName(),
                    () -> new StationBlock(BlockBehaviour.Properties.of()
                            .mapColor(MapColor.STONE).strength(2.0f).sound(SoundType.STONE), type)));
        }
        for (String ingredient : FoodIds.INGREDIENTS) {
            CRATES.put(ingredient, BLOCKS.register("crate_" + ingredient,
                    () -> new IngredientCrateBlock(BlockBehaviour.Properties.of()
                            .mapColor(MapColor.WOOD).strength(1.5f).sound(SoundType.WOOD),
                            ResourceLocation.fromNamespaceAndPath(CuteCafe.MOD_ID, ingredient))));
        }
    }
}
