package com.cutecafe.registry;

import com.cutecafe.CuteCafe;
import com.cutecafe.entity.CustomerEntity;
import com.cutecafe.entity.StaffEntity;
import net.minecraft.core.registries.Registries;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.neoforged.neoforge.event.entity.EntityAttributeCreationEvent;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

public class ModEntities {
    public static final DeferredRegister<EntityType<?>> ENTITIES =
            DeferredRegister.create(Registries.ENTITY_TYPE, CuteCafe.MOD_ID);

    public static final DeferredHolder<EntityType<?>, EntityType<CustomerEntity>> CUSTOMER =
            ENTITIES.register("customer", () -> EntityType.Builder
                    .of(CustomerEntity::new, MobCategory.CREATURE)
                    .sized(0.6f, 1.4f).clientTrackingRange(8).build("customer"));

    public static final DeferredHolder<EntityType<?>, EntityType<StaffEntity>> STAFF =
            ENTITIES.register("staff", () -> EntityType.Builder
                    .of(StaffEntity::new, MobCategory.CREATURE)
                    .sized(0.6f, 1.4f).clientTrackingRange(8).build("staff"));

    public static void registerAttributes(EntityAttributeCreationEvent event) {
        event.put(CUSTOMER.get(), CustomerEntity.createAttributes().build());
        event.put(STAFF.get(), StaffEntity.createAttributes().build());
    }
}
