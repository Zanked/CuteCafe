package com.cutecafe.dish;

import com.cutecafe.CuteCafe;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonElement;
import com.mojang.serialization.JsonOps;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.packs.resources.ResourceManager;
import net.minecraft.server.packs.resources.SimpleJsonResourceReloadListener;
import net.minecraft.util.RandomSource;
import net.minecraft.util.profiling.ProfilerFiller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;

public class DishManager extends SimpleJsonResourceReloadListener {
    private static final Gson GSON = new GsonBuilder().create();
    public static final DishManager INSTANCE = new DishManager();

    private Map<ResourceLocation, Dish> dishes = Map.of();

    private DishManager() {
        super(GSON, "cafe_dishes");
    }

    @Override
    protected void apply(Map<ResourceLocation, JsonElement> objects, ResourceManager manager, ProfilerFiller profiler) {
        Map<ResourceLocation, Dish> loaded = new HashMap<>();
        objects.forEach((id, json) -> Dish.CODEC.parse(JsonOps.INSTANCE, json)
                .resultOrPartial(err -> CuteCafe.LOGGER.error("Bad dish {}: {}", id, err))
                .ifPresent(dish -> loaded.put(id, dish)));
        this.dishes = Map.copyOf(loaded);
        CuteCafe.LOGGER.info("Loaded {} cafe dishes", dishes.size());
    }

    public Set<ResourceLocation> allIds() {
        return dishes.keySet();
    }

    public Optional<Dish> get(ResourceLocation id) {
        return Optional.ofNullable(dishes.get(id));
    }

    public Optional<ResourceLocation> randomId(RandomSource random) {
        if (dishes.isEmpty()) return Optional.empty();
        List<ResourceLocation> ids = new ArrayList<>(dishes.keySet());
        return Optional.of(ids.get(random.nextInt(ids.size())));
    }
}
