package com.cutecafe.dish;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.minecraft.resources.ResourceLocation;

import java.util.List;

/**
 * A menu entry, loaded from data/<namespace>/cafe_dishes/<name>.json
 *
 * @param result      item the customer wants to receive
 * @param ingredients items needed to cook it (used later by stoves)
 * @param price       payment in emeralds (placeholder currency)
 * @param cookTime    cooking time in ticks (used later by stoves)
 */
public record Dish(ResourceLocation result, List<ResourceLocation> ingredients, int price, int cookTime) {
    public static final Codec<Dish> CODEC = RecordCodecBuilder.create(i -> i.group(
            ResourceLocation.CODEC.fieldOf("result").forGetter(Dish::result),
            ResourceLocation.CODEC.listOf().optionalFieldOf("ingredients", List.of()).forGetter(Dish::ingredients),
            Codec.INT.optionalFieldOf("price", 1).forGetter(Dish::price),
            Codec.INT.optionalFieldOf("cook_time", 100).forGetter(Dish::cookTime)
    ).apply(i, Dish::new));
}
