package com.cutecafe;

import com.cutecafe.dish.DishManager;
import com.cutecafe.food.StationRecipes;
import com.cutecafe.menu.CashRegisters;
import com.cutecafe.menu.MenuBoards;
import com.cutecafe.network.ModNetwork;
import com.cutecafe.order.OrderBoard;
import com.cutecafe.registry.ModBlockEntities;
import com.cutecafe.registry.ModBlocks;
import com.cutecafe.registry.ModCreativeTabs;
import com.cutecafe.registry.ModEntities;
import com.cutecafe.registry.ModItems;
import com.mojang.logging.LogUtils;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.common.Mod;
import net.neoforged.neoforge.common.NeoForge;
import net.neoforged.neoforge.event.AddReloadListenerEvent;
import net.neoforged.neoforge.event.server.ServerStoppedEvent;
import org.slf4j.Logger;

@Mod(CuteCafe.MOD_ID)
public class CuteCafe {
    public static final String MOD_ID = "cutecafe";
    public static final Logger LOGGER = LogUtils.getLogger();

    public CuteCafe(IEventBus modBus) {
        ModBlocks.BLOCKS.register(modBus);
        ModBlockEntities.BLOCK_ENTITIES.register(modBus);
        ModItems.ITEMS.register(modBus);
        ModEntities.ENTITIES.register(modBus);
        ModCreativeTabs.TABS.register(modBus);

        modBus.addListener(ModEntities::registerAttributes);
        modBus.addListener(ModNetwork::register);

        NeoForge.EVENT_BUS.addListener(CuteCafe::onAddReloadListeners);
        NeoForge.EVENT_BUS.addListener(CuteCafe::onServerStopped);
    }

    private static void onAddReloadListeners(AddReloadListenerEvent event) {
        event.addListener(DishManager.INSTANCE);
        event.addListener(StationRecipes.INSTANCE);
    }

    private static void onServerStopped(ServerStoppedEvent event) {
        OrderBoard.clear();
        MenuBoards.clear();
        CashRegisters.clear();
    }
}
