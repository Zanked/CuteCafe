package com.cutecafe.block;

import com.cutecafe.menu.CashRegisters;
import com.cutecafe.registry.ModBlockEntities;
import net.minecraft.core.BlockPos;
import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;

/** The cafe's money: cashiers deposit payments here, wages are paid out of it. */
public class CashRegisterBlockEntity extends BlockEntity {
    private int balance;

    public CashRegisterBlockEntity(BlockPos pos, BlockState state) {
        super(ModBlockEntities.CASH_REGISTER.get(), pos, state);
    }

    @Override
    public void onLoad() {
        super.onLoad();
        if (level != null && !level.isClientSide) CashRegisters.add(level, worldPosition);
    }

    @Override
    public void setRemoved() {
        super.setRemoved();
        if (level != null && !level.isClientSide) CashRegisters.remove(level, worldPosition);
    }

    public int balance() {
        return balance;
    }

    public void deposit(int amount) {
        if (amount <= 0) return;
        balance += amount;
        setChanged();
    }

    /** Takes the amount if there is enough. */
    public boolean withdraw(int amount) {
        if (amount > balance) return false;
        balance -= amount;
        setChanged();
        return true;
    }

    public int takeAll() {
        int all = balance;
        balance = 0;
        setChanged();
        return all;
    }

    @Override
    protected void saveAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.saveAdditional(tag, registries);
        tag.putInt("Balance", balance);
    }

    @Override
    protected void loadAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.loadAdditional(tag, registries);
        balance = tag.getInt("Balance");
    }
}
