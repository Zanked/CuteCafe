package com.cutecafe.block;

import com.cutecafe.food.StationRecipe;
import com.cutecafe.food.StationRecipes;
import com.cutecafe.food.StationType;
import com.cutecafe.registry.ModBlockEntities;
import net.minecraft.core.BlockPos;
import net.minecraft.core.HolderLookup;
import net.minecraft.core.NonNullList;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.Containers;
import net.minecraft.world.ContainerHelper;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;

import javax.annotation.Nullable;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/**
 * Holds up to 4 ingredients. Empty-hand click makes a matching recipe: instant recipes
 * hand the result over at once, timed ones cook until DONE and wait to be collected.
 */
public class StationBlockEntity extends BlockEntity {
    public static final int SLOTS = 4;

    private enum State { IDLE, COOKING, DONE }

    private final StationType type;
    private final NonNullList<ItemStack> items = NonNullList.withSize(SLOTS, ItemStack.EMPTY);
    private State state = State.IDLE;
    @Nullable private ResourceLocation pendingOutput;
    private int progress;
    private int total;

    public StationBlockEntity(BlockPos pos, BlockState state) {
        super(ModBlockEntities.STATION.get(), pos, state);
        this.type = ((StationBlock) state.getBlock()).type();
    }

    // ---------- interaction ----------

    public void addItem(Player player, ItemStack held) {
        if (state != State.IDLE) {
            say(player, state == State.COOKING ? "cutecafe.station.busy" : "cutecafe.station.collect_first");
            return;
        }
        ResourceLocation id = BuiltInRegistries.ITEM.getKey(held.getItem());
        if (!StationRecipes.INSTANCE.accepts(type, id)) {
            say(player, "cutecafe.station.rejected", held.getHoverName());
            return;
        }
        int slot = firstEmptySlot();
        if (slot < 0) {
            say(player, "cutecafe.station.full");
            return;
        }
        items.set(slot, held.copyWithCount(1));
        if (!player.getAbilities().instabuild) held.shrink(1);
        setChanged();
        level.playSound(null, worldPosition, SoundEvents.ITEM_FRAME_ADD_ITEM, SoundSource.BLOCKS, 1.0f, 1.0f);
        say(player, "cutecafe.station.added", held.getHoverName(), usedSlots() + "/" + SLOTS);
    }

    public void interact(Player player) {
        switch (state) {
            case COOKING -> say(player, "cutecafe.station.cooking", (progress * 100 / Math.max(1, total)) + "%");
            case DONE -> {
                ItemStack out = items.get(0).copy();
                clearItems();
                state = State.IDLE;
                pendingOutput = null;
                setChanged();
                give(player, out);
                say(player, "cutecafe.station.done", out.getHoverName());
            }
            case IDLE -> {
                if (player.isShiftKeyDown()) {
                    returnContents(player);
                    return;
                }
                List<ItemStack> contents = new ArrayList<>();
                for (ItemStack s : items) if (!s.isEmpty()) contents.add(s);
                if (contents.isEmpty()) {
                    say(player, "cutecafe.station.empty");
                    return;
                }
                Optional<StationRecipe> recipe = StationRecipes.INSTANCE.find(type, contents);
                if (recipe.isEmpty()) {
                    say(player, "cutecafe.station.no_recipe");
                    return;
                }
                StationRecipe r = recipe.get();
                if (r.time() <= 0) {
                    clearItems();
                    ItemStack out = new ItemStack(BuiltInRegistries.ITEM.get(r.output()));
                    setChanged();
                    give(player, out.copy());
                    level.playSound(null, worldPosition, SoundEvents.UI_STONECUTTER_TAKE_RESULT, SoundSource.BLOCKS, 1.0f, 1.0f);
                    say(player, "cutecafe.station.done", out.getHoverName());
                } else {
                    state = State.COOKING;
                    pendingOutput = r.output();
                    total = r.time();
                    progress = 0;
                    setChanged();
                    say(player, "cutecafe.station.started");
                }
            }
        }
    }

    private void returnContents(Player player) {
        boolean any = false;
        for (int i = 0; i < SLOTS; i++) {
            if (!items.get(i).isEmpty()) {
                give(player, items.get(i).copy());
                items.set(i, ItemStack.EMPTY);
                any = true;
            }
        }
        if (any) {
            setChanged();
            say(player, "cutecafe.station.returned");
        } else {
            say(player, "cutecafe.station.empty");
        }
    }

    // ---------- cooking ----------

    public static void serverTick(Level level, BlockPos pos, BlockState blockState, StationBlockEntity be) {
        if (be.state != State.COOKING) return;
        be.progress++;
        if (be.progress % 10 == 0 && level instanceof ServerLevel sl) {
            sl.sendParticles(ParticleTypes.SMOKE, pos.getX() + 0.5, pos.getY() + 1.0, pos.getZ() + 0.5, 2, 0.15, 0.05, 0.15, 0.01);
            if (be.type == StationType.GRILL) {
                sl.sendParticles(ParticleTypes.FLAME, pos.getX() + 0.5, pos.getY() + 1.0, pos.getZ() + 0.5, 1, 0.2, 0.0, 0.2, 0.0);
            }
        }
        if (be.progress >= be.total) {
            be.clearItems();
            ItemStack out = be.pendingOutput == null ? ItemStack.EMPTY
                    : new ItemStack(BuiltInRegistries.ITEM.get(be.pendingOutput));
            be.items.set(0, out);
            be.state = State.DONE;
            be.setChanged();
            level.playSound(null, pos, SoundEvents.NOTE_BLOCK_BELL.value(), SoundSource.BLOCKS, 1.0f, 1.2f);
        }
    }

    // ---------- helpers ----------

    public void dropContents(Level level, BlockPos pos) {
        for (ItemStack s : items) {
            if (!s.isEmpty()) Containers.dropItemStack(level, pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5, s);
        }
        clearItems();
    }

    private void clearItems() {
        for (int i = 0; i < SLOTS; i++) items.set(i, ItemStack.EMPTY);
    }

    private int firstEmptySlot() {
        for (int i = 0; i < SLOTS; i++) if (items.get(i).isEmpty()) return i;
        return -1;
    }

    private int usedSlots() {
        int n = 0;
        for (ItemStack s : items) if (!s.isEmpty()) n++;
        return n;
    }

    private static void give(Player player, ItemStack stack) {
        if (stack.isEmpty()) return;
        if (!player.addItem(stack)) player.drop(stack, false);
    }

    private static void say(Player player, String key, Object... args) {
        player.displayClientMessage(Component.translatable(key, args), true);
    }

    // ---------- save / load ----------

    @Override
    protected void saveAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.saveAdditional(tag, registries);
        ContainerHelper.saveAllItems(tag, items, registries);
        tag.putString("State", state.name());
        tag.putInt("Progress", progress);
        tag.putInt("Total", total);
        if (pendingOutput != null) tag.putString("Output", pendingOutput.toString());
    }

    @Override
    protected void loadAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.loadAdditional(tag, registries);
        clearItems();
        ContainerHelper.loadAllItems(tag, items, registries);
        try {
            state = State.valueOf(tag.getString("State"));
        } catch (IllegalArgumentException e) {
            state = State.IDLE;
        }
        progress = tag.getInt("Progress");
        total = tag.getInt("Total");
        pendingOutput = tag.contains("Output") ? ResourceLocation.tryParse(tag.getString("Output")) : null;
    }
}
