package com.cutecafe.block;

import com.cutecafe.dish.DishManager;
import com.cutecafe.entity.CustomerEntity;
import com.cutecafe.menu.CafeMenu;
import com.cutecafe.registry.ModEntities;
import com.mojang.serialization.MapCodec;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.RandomSource;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.properties.BooleanProperty;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;

/**
 * Right-click to open / close the cafe. While open, new customers walk in at random
 * intervals, as long as there are fewer customers than tables nearby.
 */
public class CafeEntranceBlock extends Block {
    public static final MapCodec<CafeEntranceBlock> CODEC = simpleCodec(CafeEntranceBlock::new);
    public static final BooleanProperty OPEN = BlockStateProperties.OPEN;

    /** A customer may arrive every MIN..MIN+RANDOM ticks. */
    private static final int MIN_INTERVAL = 200;
    private static final int RANDOM_INTERVAL = 300;
    private static final int TABLE_RADIUS_H = 16;
    private static final int TABLE_RADIUS_V = 3;

    public CafeEntranceBlock(Properties properties) {
        super(properties);
        registerDefaultState(stateDefinition.any().setValue(OPEN, false));
    }

    @Override
    protected MapCodec<CafeEntranceBlock> codec() {
        return CODEC;
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        builder.add(OPEN);
    }

    @Override
    protected void onPlace(BlockState state, Level level, BlockPos pos, BlockState oldState, boolean movedByPiston) {
        if (!level.isClientSide && !oldState.is(this)) {
            level.scheduleTick(pos, this, 100);
        }
    }

    @Override
    protected void tick(BlockState state, ServerLevel level, BlockPos pos, RandomSource random) {
        if (state.getValue(OPEN)) trySpawnCustomer(level, pos);
        level.scheduleTick(pos, this, MIN_INTERVAL + random.nextInt(RANDOM_INTERVAL));
    }

    @Override
    protected InteractionResult useWithoutItem(BlockState state, Level level, BlockPos pos, Player player, BlockHitResult hit) {
        if (!level.isClientSide) {
            BlockState toggled = state.cycle(OPEN);
            level.setBlock(pos, toggled, 3);
            player.displayClientMessage(Component.translatable(
                    toggled.getValue(OPEN) ? "cutecafe.entrance.open" : "cutecafe.entrance.closed"), true);
        }
        return InteractionResult.sidedSuccess(level.isClientSide);
    }

    private void trySpawnCustomer(ServerLevel level, BlockPos pos) {
        if (CafeMenu.available(level, pos).isEmpty()) return; // nothing to order

        int tables = 0;
        for (BlockPos p : BlockPos.betweenClosed(
                pos.offset(-TABLE_RADIUS_H, -TABLE_RADIUS_V, -TABLE_RADIUS_H),
                pos.offset(TABLE_RADIUS_H, TABLE_RADIUS_V, TABLE_RADIUS_H))) {
            if (level.hasChunkAt(p) && level.getBlockState(p).getBlock() instanceof TableBlock) tables++;
        }
        if (tables == 0) return;

        int customers = level.getEntitiesOfClass(CustomerEntity.class, new AABB(pos).inflate(32)).size();
        if (customers >= tables) return;

        BlockPos spot = SpawnSpots.near(level, pos);
        if (spot == null) return;
        ModEntities.CUSTOMER.get().spawn(level, spot, MobSpawnType.EVENT);
    }
}
