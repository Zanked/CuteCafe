package com.cutecafe.block;

import com.cutecafe.entity.StaffEntity;
import com.cutecafe.registry.ModEntities;
import com.mojang.serialization.MapCodec;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.ItemInteractionResult;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.EnumProperty;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;

/**
 * Hire helpers: right-click (empty hand) to choose a role, right-click holding
 * emeralds to pay and hire one.
 */
public class JobBoardBlock extends Block {
    public static final MapCodec<JobBoardBlock> CODEC = simpleCodec(JobBoardBlock::new);
    public static final EnumProperty<StaffEntity.Role> ROLE = EnumProperty.create("role", StaffEntity.Role.class);

    /** Price of one helper, in emeralds. */
    public static final int HIRE_COST = 12;
    /** Most helpers allowed around one board. */
    public static final int MAX_STAFF = 8;

    public JobBoardBlock(Properties properties) {
        super(properties);
        registerDefaultState(stateDefinition.any().setValue(ROLE, StaffEntity.Role.COOK));
    }

    @Override
    protected MapCodec<JobBoardBlock> codec() {
        return CODEC;
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        builder.add(ROLE);
    }

    private static Component roleName(StaffEntity.Role role) {
        return Component.translatable("cutecafe.role." + role.getSerializedName());
    }

    /** Empty hand (or any non-emerald item): pick the next role. */
    @Override
    protected InteractionResult useWithoutItem(BlockState state, Level level, BlockPos pos, Player player, BlockHitResult hit) {
        if (!level.isClientSide) {
            BlockState next = state.cycle(ROLE);
            level.setBlock(pos, next, 3);
            player.displayClientMessage(Component.translatable("cutecafe.job.selected",
                    roleName(next.getValue(ROLE)), HIRE_COST, next.getValue(ROLE).wage()), true);
        }
        return InteractionResult.sidedSuccess(level.isClientSide);
    }

    /** Holding emeralds: pay and hire. */
    @Override
    protected ItemInteractionResult useItemOn(ItemStack stack, BlockState state, Level level, BlockPos pos,
                                              Player player, InteractionHand hand, BlockHitResult hit) {
        if (!stack.is(Items.EMERALD)) return ItemInteractionResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
        if (!level.isClientSide && level instanceof ServerLevel sl) hire(sl, pos, state, player, stack);
        return ItemInteractionResult.sidedSuccess(level.isClientSide);
    }

    private void hire(ServerLevel level, BlockPos pos, BlockState state, Player player, ItemStack payment) {
        boolean creative = player.getAbilities().instabuild;
        if (!creative && payment.getCount() < HIRE_COST) {
            player.displayClientMessage(Component.translatable("cutecafe.job.not_enough", HIRE_COST), true);
            return;
        }
        if (level.getEntitiesOfClass(StaffEntity.class, new AABB(pos).inflate(48)).size() >= MAX_STAFF) {
            player.displayClientMessage(Component.translatable("cutecafe.job.limit", MAX_STAFF), true);
            return;
        }
        BlockPos spot = SpawnSpots.near(level, pos);
        if (spot == null) {
            player.displayClientMessage(Component.translatable("cutecafe.job.no_space"), true);
            return;
        }
        StaffEntity staff = ModEntities.STAFF.get().spawn(level, spot, MobSpawnType.EVENT);
        if (staff == null) return;

        StaffEntity.Role role = state.getValue(ROLE);
        staff.setRole(role);
        staff.setHired(true);
        if (!creative) payment.shrink(HIRE_COST);
        level.sendParticles(ParticleTypes.HAPPY_VILLAGER, staff.getX(), staff.getY() + 1.0, staff.getZ(), 8, 0.4, 0.5, 0.4, 0.0);
        level.playSound(null, pos, SoundEvents.VILLAGER_CELEBRATE, SoundSource.BLOCKS, 1.0f, 1.0f);
        player.displayClientMessage(Component.translatable("cutecafe.job.hired", roleName(role)), true);
    }
}
