package com.cutecafe.block;

import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;

/** Endless supply of one raw ingredient: right-click to take one. */
public class IngredientCrateBlock extends Block {
    public static final MapCodec<IngredientCrateBlock> CODEC = RecordCodecBuilder.mapCodec(i -> i.group(
            propertiesCodec(),
            ResourceLocation.CODEC.fieldOf("item").forGetter(c -> c.itemId)
    ).apply(i, IngredientCrateBlock::new));

    private final ResourceLocation itemId;

    public IngredientCrateBlock(Properties properties, ResourceLocation itemId) {
        super(properties);
        this.itemId = itemId;
    }

    @Override
    protected MapCodec<IngredientCrateBlock> codec() {
        return CODEC;
    }

    @Override
    protected InteractionResult useWithoutItem(BlockState state, Level level, BlockPos pos, Player player, BlockHitResult hit) {
        if (!level.isClientSide) {
            ItemStack stack = new ItemStack(BuiltInRegistries.ITEM.get(itemId));
            if (!player.addItem(stack)) player.drop(stack, false);
        }
        return InteractionResult.sidedSuccess(level.isClientSide);
    }
}
