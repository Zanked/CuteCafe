package com.cutecafe.block;

import com.cutecafe.dish.Dish;
import com.cutecafe.dish.DishManager;
import com.cutecafe.menu.CafeMenu;
import com.cutecafe.menu.MenuBoards;
import com.cutecafe.network.OpenMenuPayload.DishRow;
import com.cutecafe.registry.ModBlockEntities;
import net.minecraft.core.BlockPos;
import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** Stores which dishes are on this cafe's menu and at what price (dish present = on the menu). */
public class MenuBoardBlockEntity extends BlockEntity {
    public static final int MAX_PRICE = 64;

    private final Map<ResourceLocation, Integer> menu = new LinkedHashMap<>();
    private boolean initialized;

    public MenuBoardBlockEntity(BlockPos pos, BlockState state) {
        super(ModBlockEntities.MENU_BOARD.get(), pos, state);
    }

    @Override
    public void onLoad() {
        super.onLoad();
        if (level != null && !level.isClientSide) MenuBoards.add(level, worldPosition);
    }

    @Override
    public void setRemoved() {
        super.setRemoved();
        if (level != null && !level.isClientSide) MenuBoards.remove(level, worldPosition);
    }

    /** A fresh board starts with every known dish on the menu at its default price. */
    private void ensureInitialized() {
        if (initialized || DishManager.INSTANCE.allIds().isEmpty()) return;
        for (ResourceLocation id : DishManager.INSTANCE.allIds()) {
            menu.put(id, DishManager.INSTANCE.get(id).map(Dish::price).orElse(1));
        }
        initialized = true;
        setChanged();
    }

    /** Menu as customers see it. */
    public List<CafeMenu.Entry> entries() {
        ensureInitialized();
        List<CafeMenu.Entry> list = new ArrayList<>();
        menu.forEach((id, price) -> {
            if (DishManager.INSTANCE.get(id).isPresent()) list.add(new CafeMenu.Entry(id, price));
        });
        return list;
    }

    /** Every known dish, enabled or not, for the editor screen. */
    public List<DishRow> rows() {
        ensureInitialized();
        List<DishRow> rows = new ArrayList<>();
        DishManager.INSTANCE.allIds().stream().sorted().forEach(id ->
                DishManager.INSTANCE.get(id).ifPresent(d ->
                        rows.add(new DishRow(id, d.result(), menu.containsKey(id), menu.getOrDefault(id, d.price())))));
        return rows;
    }

    public void setDish(ResourceLocation id, boolean enabled, int price) {
        if (DishManager.INSTANCE.get(id).isEmpty()) return;
        ensureInitialized();
        if (enabled) menu.put(id, Mth.clamp(price, 1, MAX_PRICE));
        else menu.remove(id);
        setChanged();
    }

    @Override
    protected void saveAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.saveAdditional(tag, registries);
        tag.putBoolean("Initialized", initialized);
        ListTag list = new ListTag();
        menu.forEach((id, price) -> {
            CompoundTag entry = new CompoundTag();
            entry.putString("Dish", id.toString());
            entry.putInt("Price", price);
            list.add(entry);
        });
        tag.put("Menu", list);
    }

    @Override
    protected void loadAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.loadAdditional(tag, registries);
        initialized = tag.getBoolean("Initialized");
        menu.clear();
        ListTag list = tag.getList("Menu", Tag.TAG_COMPOUND);
        for (int i = 0; i < list.size(); i++) {
            CompoundTag entry = list.getCompound(i);
            ResourceLocation id = ResourceLocation.tryParse(entry.getString("Dish"));
            if (id != null) menu.put(id, Mth.clamp(entry.getInt("Price"), 1, MAX_PRICE));
        }
    }
}
