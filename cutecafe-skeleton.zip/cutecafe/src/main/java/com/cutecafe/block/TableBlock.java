package com.cutecafe.block;

import com.mojang.serialization.MapCodec;
import net.minecraft.world.level.block.Block;

/** Customers look for these blocks to sit down and order. */
public class TableBlock extends Block {
    public static final MapCodec<TableBlock> CODEC = simpleCodec(TableBlock::new);

    public TableBlock(Properties properties) {
        super(properties);
    }

    @Override
    protected MapCodec<TableBlock> codec() {
        return CODEC;
    }
}
