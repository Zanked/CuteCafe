package com.cutecafe.block;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.level.Level;

import javax.annotation.Nullable;

public class SpawnSpots {
    /** A free standing spot (2 blocks of air on solid ground) 1-2 blocks away from origin, or null. */
    @Nullable
    public static BlockPos near(Level level, BlockPos origin) {
        for (int dist = 1; dist <= 2; dist++) {
            for (Direction dir : Direction.Plane.HORIZONTAL) {
                BlockPos p = origin.relative(dir, dist);
                if (isFree(level, p)) return p;
            }
        }
        return null;
    }

    private static boolean isFree(Level level, BlockPos p) {
        BlockPos below = p.below();
        return level.getBlockState(p).getCollisionShape(level, p).isEmpty()
                && level.getBlockState(p.above()).getCollisionShape(level, p.above()).isEmpty()
                && level.getBlockState(below).isFaceSturdy(level, below, Direction.UP);
    }
}
