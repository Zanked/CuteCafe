package com.cutecafe.block;

import com.cutecafe.network.OpenMenuPayload;
import com.mojang.serialization.MapCodec;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.BaseEntityBlock;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;
import net.neoforged.neoforge.network.PacketDistributor;

/** Right-click to edit the cafe menu. Customers use the nearest board. */
public class MenuBoardBlock extends BaseEntityBlock {
    public static final MapCodec<MenuBoardBlock> CODEC = simpleCodec(MenuBoardBlock::new);

    public MenuBoardBlock(Properties properties) {
        super(properties);
    }

    @Override
    protected MapCodec<MenuBoardBlock> codec() {
        return CODEC;
    }

    @Override
    public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
        return new MenuBoardBlockEntity(pos, state);
    }

    @Override
    protected RenderShape getRenderShape(BlockState state) {
        return RenderShape.MODEL;
    }

    @Override
    protected InteractionResult useWithoutItem(BlockState state, Level level, BlockPos pos, Player player, BlockHitResult hit) {
        if (!level.isClientSide && player instanceof ServerPlayer sp
                && level.getBlockEntity(pos) instanceof MenuBoardBlockEntity board) {
            PacketDistributor.sendToPlayer(sp, new OpenMenuPayload(pos, board.rows()));
        }
        return InteractionResult.sidedSuccess(level.isClientSide);
    }
}
