package com.cutecafe.block;

import com.mojang.serialization.MapCodec;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.ItemInteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.BaseEntityBlock;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;

/**
 * Empty hand: show the balance. Sneak + empty hand: take all the money.
 * Holding emeralds: deposit them (to cover wages).
 */
public class CashRegisterBlock extends BaseEntityBlock {
    public static final MapCodec<CashRegisterBlock> CODEC = simpleCodec(CashRegisterBlock::new);

    public CashRegisterBlock(Properties properties) {
        super(properties);
    }

    @Override
    protected MapCodec<CashRegisterBlock> codec() {
        return CODEC;
    }

    @Override
    public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
        return new CashRegisterBlockEntity(pos, state);
    }

    @Override
    protected RenderShape getRenderShape(BlockState state) {
        return RenderShape.MODEL;
    }

    @Override
    protected ItemInteractionResult useItemOn(ItemStack stack, BlockState state, Level level, BlockPos pos,
                                              Player player, InteractionHand hand, BlockHitResult hit) {
        if (!stack.is(Items.EMERALD)) return ItemInteractionResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
        if (!level.isClientSide && level.getBlockEntity(pos) instanceof CashRegisterBlockEntity be) {
            int amount = stack.getCount();
            be.deposit(amount);
            if (!player.getAbilities().instabuild) stack.shrink(amount);
            player.displayClientMessage(Component.translatable("cutecafe.register.deposited", amount, be.balance()), true);
        }
        return ItemInteractionResult.sidedSuccess(level.isClientSide);
    }

    @Override
    protected InteractionResult useWithoutItem(BlockState state, Level level, BlockPos pos, Player player, BlockHitResult hit) {
        if (!level.isClientSide && level.getBlockEntity(pos) instanceof CashRegisterBlockEntity be) {
            if (player.isShiftKeyDown()) {
                int taken = be.takeAll();
                for (int left = taken; left > 0; ) {
                    int n = Math.min(64, left);
                    ItemStack coins = new ItemStack(Items.EMERALD, n);
                    if (!player.addItem(coins)) player.drop(coins, false);
                    left -= n;
                }
                player.displayClientMessage(Component.translatable("cutecafe.register.withdrew", taken), true);
            } else {
                player.displayClientMessage(Component.translatable("cutecafe.register.balance", be.balance()), true);
            }
        }
        return InteractionResult.sidedSuccess(level.isClientSide);
    }
}
